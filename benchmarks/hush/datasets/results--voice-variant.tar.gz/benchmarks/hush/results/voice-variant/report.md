# hush benchmark — run `voice-variant`

36 runs · model `haiku` · generated from `results/voice-variant/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.0178 | 622 | 21380 | 0 | 237 | 1.0 | 12 |
| **hush** | 100% | 0.0202 | 615 | 22634 | 0 | 190 | 1.0 | 11 |
| **hush-caveman-voice** | 92% | 0.0202 | 606 | 22649 | 0 | 176 | 1.0 | 12 |

Deltas vs baseline — cost: hush +14%, hush-caveman-voice +14%; output tokens: hush -1%, hush-caveman-voice -3%; context traffic: hush +6%, hush-caveman-voice +6%.

## explain-rebase

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.94 | 0.0176 | 591 (0%) | 21379 (0%) | 0 | 263 | 0 | 1.0 |
| hush | 100% | 0.94 | 0.0201 | 600 (+2%) | 22633 (+6%) | 0 | 216 | 0 | 1.0 |
| hush-caveman-voice | 100% | 1.00 | 0.0203 | 620 (+5%) | 22648 (+6%) | 0 | 208 | 0 | 1.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.72 | 0.0179 | 653 (0%) | 21380 (0%) | 0 | 211 | 0 | 1.0 |
| hush | 100% | 0.78 | 0.0203 | 630 (-3%) | 22634 (+6%) | 0 | 164 | 0 | 1.0 |
| hush-caveman-voice | 83% | 0.72 | 0.0201 | 592 (-9%) | 22649 (+6%) | 0 | 145 | 0 | 1.0 |
