# hush benchmark — run `hero`

72 runs · model `sonnet` · generated from `results/hero/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.3575 | 4789 | 394417 | 42 | 144 | 16.0 | 56 |
| **hushmax** | 100% | 0.3727 | 4253 | 427809 | 5 | 77 | 15.5 | 54 |

Deltas vs baseline — cost: hushmax +4%; output tokens: hushmax -11%; context traffic: hushmax +8%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 12 | 0.3903 | 0.4116 | 0.3725–0.4121 | 0.3694–0.4538 | — | — | — | 100% |
| long-session | hushmax | 12 | 0.4032 | 0.4578 | 0.3252–0.5463 | 0.3681–0.5475 | +3.3% | 50% | feature-drift +42.0% | 100% |
| noisy-output | baseline | 18 | 0.2115 | 0.2341 | 0.1855–0.3053 | 0.2074–0.2608 | — | — | — | 100% |
| noisy-output | hushmax | 18 | 0.2188 | 0.2388 | 0.2098–0.2519 | 0.2106–0.2670 | +3.4% | 33% | failing-suite +19.4% | 100% |
| search-heavy | baseline | 6 | 0.5922 | 0.6197 | 0.5606–0.6757 | 0.5456–0.6939 | — | — | — | 100% |
| search-heavy | hushmax | 6 | 0.6595 | 0.6041 | 0.5572–0.6829 | 0.5036–0.7045 | +11.4% | 0% | repo-sweep +11.4% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 12 | 561060 | 556553 | 430524–612945 | 475267–637838 | — | — | — | 100% |
| long-session | hushmax | 12 | 582291 | 646354 | 533999–722816 | 551995–740714 | +3.8% | 50% | feature-drift +73.2% | 100% |
| noisy-output | baseline | 18 | 255806 | 256455 | 185945–315071 | 226931–285978 | — | — | — | 100% |
| noisy-output | hushmax | 18 | 280730 | 284197 | 235856–312213 | 229795–338598 | +9.7% | 33% | log-triage +6.9% | 100% |
| search-heavy | baseline | 6 | 399757 | 484033 | 351792–578869 | 332899–635166 | — | — | — | 100% |
| search-heavy | hushmax | 6 | 402671 | 421557 | 357144–433288 | 346743–496370 | +0.7% | 0% | repo-sweep +0.7% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 12 | 5915 | 6852 | 4686–8440 | 5348–8356 | — | — | — | 100% |
| long-session | hushmax | 12 | 5040 | 5935 | 2618–8475 | 3829–8041 | -14.8% | 100% | — | 100% |
| noisy-output | baseline | 18 | 1796 | 1685 | 1313–1973 | 1514–1857 | — | — | — | 100% |
| noisy-output | hushmax | 18 | 1682 | 1566 | 1165–1844 | 1339–1792 | -6.3% | 67% | failing-suite +2.3% | 100% |
| search-heavy | baseline | 6 | 10396 | 9971 | 10043–10968 | 8550–11391 | — | — | — | 100% |
| search-heavy | hushmax | 6 | 9991 | 8952 | 7266–10847 | 6196–11707 | -3.9% | 100% | — | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 12 | 22 | 37 | 0–68 | 14–60 | — | — | — | 100% |
| long-session | hushmax | 12 | 0 | 0 | 0–0 | 0–0 | -100.0% | 100% | — | 100% |
| noisy-output | baseline | 18 | 35 | 33 | 14–42 | 23–43 | — | — | — | 100% |
| noisy-output | hushmax | 18 | 0 | 5 | 0–0 | -0–9 | -100.0% | 100% | — | 100% |
| search-heavy | baseline | 6 | 78 | 79 | 60–96 | 53–105 | — | — | — | 100% |
| search-heavy | hushmax | 6 | 17 | 19 | 15–22 | 14–23 | -78.8% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2009 | 1970 (0%) | 286234 (0%) | 51 | 106 | 9194 | 11.0 |
| hushmax | 100% | 1.00 | 0.2238 | 1820 (-8%) | 295670 (+3%) | 4 | 81 | 8113 | 9.8 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1905 | 1425 (0%) | 297221 (0%) | 39 | 46 | 8986 | 8.7 |
| hushmax | 100% | 1.00 | 0.2488 | 1653 (+16%) | 347877 (+17%) | 10 | 38 | 12853 | 10.2 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4304 | 8955 (0%) | 535036 (0%) | 74 | 46 | 13035 | 15.5 |
| hushmax | 100% | 1.00 | 0.5866 | 9234 (+3%) | 751888 (+41%) | 0 | 23 | 14583 | 18.5 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3928 | 4750 (0%) | 578069 (0%) | 0 | 266 | 23947 | 14.2 |
| hushmax | 100% | 1.00 | 0.3290 | 2637 (-44%) | 540820 (-6%) | 0 | 122 | 12024 | 12.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3109 | 1662 (0%) | 185909 (0%) | 10 | 355 | 60306 | 4.0 |
| hushmax | 100% | 1.00 | 0.2437 | 1224 (-26%) | 209043 (+12%) | 0 | 160 | 29182 | 5.2 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.6197 | 9971 (0%) | 484033 (0%) | 79 | 47 | 29612 | 42.5 |
| hushmax | 100% | 1.00 | 0.6041 | 8952 (-10%) | 421557 (-13%) | 19 | 37 | 33095 | 37.0 |
