# hush benchmark — run `concise270`

24 runs · model `opus` · generated from `results/concise270/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.5016 | 5992 | 305115 | 25 | 411 | 12.3 | 94 |
| **concise** | 100% | 0.5774 | 6322 | 315170 | 23 | 386 | 23.1 | 82 |
| **fragment** | 88% | 0.5607 | 4191 | 298684 | 4 | 49 | 15.6 | 62 |

Deltas vs baseline — cost: concise +15%, fragment +12%; output tokens: concise +5%, fragment -30%; context traffic: concise +3%, fragment -2%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 0.9976 | 0.9976 | 0.9776–1.0177 | 0.9190–1.0762 | — | — | — | 100% |
| long-session | concise | 2 | 0.6840 | 0.6840 | 0.6364–0.7317 | 0.4972–0.8709 | -31.4% | 100% | — | 100% |
| long-session | fragment | 2 | 0.6718 | 0.6718 | 0.6166–0.7271 | 0.4552–0.8884 | -32.7% | 100% | — | 50% |
| noisy-output | baseline | 4 | 0.2727 | 0.3239 | 0.2609–0.3357 | 0.2066–0.4412 | — | — | — | 100% |
| noisy-output | concise | 4 | 0.3128 | 0.4032 | 0.2986–0.4174 | 0.2072–0.5991 | +14.7% | 0% | log-triage +30.9% | 100% |
| noisy-output | fragment | 4 | 0.4169 | 0.4540 | 0.3027–0.5682 | 0.2659–0.6422 | +52.9% | 0% | log-triage +55.8% | 100% |
| search-heavy | baseline | 2 | 0.3609 | 0.3609 | 0.3505–0.3713 | 0.3201–0.4016 | — | — | — | 100% |
| search-heavy | concise | 2 | 0.8192 | 0.8192 | 0.8069–0.8315 | 0.7711–0.8673 | +127.0% | 0% | repo-sweep +127.0% | 100% |
| search-heavy | fragment | 2 | 0.6631 | 0.6631 | 0.5220–0.8042 | 0.1101–1.2161 | +83.8% | 0% | repo-sweep +83.8% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 645247 | 645247 | 641994–648500 | 632495–657999 | — | — | — | 100% |
| long-session | concise | 2 | 467508 | 467508 | 445475–489542 | 381137–553879 | -27.5% | 100% | — | 100% |
| long-session | fragment | 2 | 554992 | 554992 | 489023–620960 | 296394–813589 | -14.0% | 100% | — | 50% |
| noisy-output | baseline | 4 | 188655 | 183286 | 177189–194752 | 162383–204188 | — | — | — | 100% |
| noisy-output | concise | 4 | 215354 | 209720 | 196265–228809 | 183934–235506 | +14.2% | 0% | log-triage +28.9% | 100% |
| noisy-output | fragment | 4 | 187992 | 191053 | 164523–214521 | 160627–221479 | -0.4% | 50% | failing-suite +10.2% | 100% |
| search-heavy | baseline | 2 | 208640 | 208640 | 207991–209289 | 206096–211184 | — | — | — | 100% |
| search-heavy | concise | 2 | 373732 | 373732 | 363652–383811 | 334219–413244 | +79.1% | 0% | repo-sweep +79.1% | 100% |
| search-heavy | fragment | 2 | 257639 | 257639 | 247040–268237 | 216093–299184 | +23.5% | 0% | repo-sweep +23.5% | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 35847 | 35847 | 35666–36028 | 35139–36555 | — | — | — | 100% |
| long-session | concise | 2 | 33393 | 33393 | 31820–34967 | 27224–39563 | -6.8% | 100% | — | 100% |
| long-session | fragment | 2 | 33445 | 33445 | 32994–33895 | 31677–35212 | -6.7% | 100% | — | 50% |
| noisy-output | baseline | 4 | 25992 | 26191 | 25479–26704 | 25241–27140 | — | — | — | 100% |
| noisy-output | concise | 4 | 28824 | 31043 | 27792–32075 | 24613–37474 | +10.9% | 0% | log-triage +28.0% | 100% |
| noisy-output | fragment | 4 | 36543 | 36107 | 31522–41128 | 30380–41833 | +40.6% | 0% | log-triage +58.2% | 100% |
| search-heavy | baseline | 2 | 29806 | 29806 | 29713–29898 | 29442–30169 | — | — | — | 100% |
| search-heavy | concise | 2 | 39337 | 39337 | 39312–39363 | 39236–39439 | +32.0% | 0% | repo-sweep +32.0% | 100% |
| search-heavy | fragment | 2 | 36806 | 36806 | 35291–38320 | 30870–42741 | +23.5% | 0% | repo-sweep +23.5% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 14342 | 14342 | 13904–14779 | 12626–16057 | — | — | — | 100% |
| long-session | concise | 2 | 8243 | 8243 | 7730–8755 | 6234–10251 | -42.5% | 100% | — | 100% |
| long-session | fragment | 2 | 6752 | 6752 | 6283–7222 | 4912–8592 | -52.9% | 100% | — | 50% |
| noisy-output | baseline | 4 | 2647 | 2845 | 1769–3723 | 1581–4109 | — | — | — | 100% |
| noisy-output | concise | 4 | 2394 | 2386 | 1979–2800 | 1672–3099 | -9.6% | 50% | failing-suite +3.6% | 100% |
| noisy-output | fragment | 4 | 1517 | 1472 | 1347–1642 | 1221–1723 | -42.7% | 100% | — | 100% |
| search-heavy | baseline | 2 | 3938 | 3938 | 3682–4193 | 2935–4940 | — | — | — | 100% |
| search-heavy | concise | 2 | 12273 | 12273 | 12125–12420 | 11695–12850 | +211.7% | 0% | repo-sweep +211.7% | 100% |
| search-heavy | fragment | 2 | 7067 | 7067 | 4933–9202 | -1300–15434 | +79.5% | 0% | repo-sweep +79.5% | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 6 | 6 | 6–6 | 6–6 | — | — | — | 100% |
| long-session | concise | 2 | 6 | 6 | 6–6 | 6–6 | +0.0% | 100% | — | 100% |
| long-session | fragment | 2 | 0 | 0 | 0–0 | 0–0 | -100.0% | 100% | — | 50% |
| noisy-output | baseline | 4 | 8 | 21 | 8–21 | -5–46 | — | — | — | 100% |
| noisy-output | concise | 4 | 25 | 33 | 10–48 | -3–68 | +206.3% | 50% | failing-suite +73.5% | 100% |
| noisy-output | fragment | 4 | 6 | 5 | 4–7 | 1–8 | -31.3% | 100% | — | 100% |
| search-heavy | baseline | 2 | 53 | 53 | 41–65 | 6–100 | — | — | — | 100% |
| search-heavy | concise | 2 | 22 | 22 | 16–27 | 1–42 | -59.4% | 100% | — | 100% |
| search-heavy | fragment | 2 | 6 | 6 | 6–6 | 6–6 | -88.7% | 100% | — | 100% |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2565 | 1765 (0%) | 197392 (0%) | 34 | 181 | 9666 | 10.5 |
| concise | 100% | 1.00 | 0.2940 | 1828 (+4%) | 201378 (+2%) | 59 | 184 | 15650 | 10.5 |
| fragment | 100% | 1.00 | 0.2985 | 1277 (-28%) | 217589 (+10%) | 4 | 45 | 9637 | 8.5 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.9976 | 14342 (0%) | 645247 (0%) | 6 | 736 | 28818 | 18.0 |
| concise | 100% | 1.00 | 0.6840 | 8243 (-43%) | 467508 (-28%) | 6 | 563 | 21684 | 17.5 |
| fragment | 50% | 0.83 | 0.6718 | 6752 (-53%) | 554992 (-14%) | 0 | 50 | 10993 | 16.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3913 | 3925 (0%) | 169180 (0%) | 7 | 537 | 9820 | 8.5 |
| concise | 100% | 1.00 | 0.5123 | 2943 (-25%) | 218063 (+29%) | 7 | 644 | 34982 | 7.5 |
| fragment | 100% | 1.00 | 0.6096 | 1667 (-58%) | 164518 (-3%) | 6 | 54 | 60197 | 4.0 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3609 | 3938 (0%) | 208640 (0%) | 53 | 189 | 15626 | 12.0 |
| concise | 100% | 1.00 | 0.8192 | 12273 (+212%) | 373732 (+79%) | 22 | 155 | 31108 | 57.0 |
| fragment | 100% | 1.00 | 0.6631 | 7067 (+79%) | 257639 (+23%) | 6 | 47 | 22342 | 33.5 |
