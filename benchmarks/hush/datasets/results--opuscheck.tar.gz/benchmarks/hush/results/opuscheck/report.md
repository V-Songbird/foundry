# hush benchmark — run `opuscheck`

24 runs · model `opus` · generated from `results/opuscheck/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.5983 | 7183 | 390227 | 47 | 467 | 15.4 | 112 |
| **hush** | 100% | 0.7491 | 6625 | 419064 | 2 | 79 | 21.8 | 103 |

Deltas vs baseline — cost: hush +25%; output tokens: hush -8%; context traffic: hush +7%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 0.9432 | 0.9629 | 0.9360–0.9700 | 0.9179–1.0080 | — | — | — | 100% |
| long-session | hush | 4 | 0.9937 | 0.9212 | 0.9072–1.0076 | 0.7489–1.0934 | +5.4% | 50% | incident-forensics +8.4% | 100% |
| noisy-output | baseline | 6 | 0.3327 | 0.3801 | 0.2925–0.3540 | 0.2520–0.5081 | — | — | — | 100% |
| noisy-output | hush | 6 | 0.3024 | 0.3259 | 0.2949–0.3646 | 0.2878–0.3639 | -9.1% | 100% | — | 100% |
| search-heavy | baseline | 2 | 0.5238 | 0.5238 | 0.5068–0.5409 | 0.4570–0.5907 | — | — | — | 100% |
| search-heavy | hush | 2 | 1.6747 | 1.6747 | 1.4177–1.9316 | 0.6673–2.6820 | +219.7% | 0% | repo-sweep +219.7% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 669253 | 705197 | 564420–810029 | 513853–896540 | — | — | — | 100% |
| long-session | hush | 4 | 769091 | 738053 | 689461–817683 | 569720–906386 | +14.9% | 50% | incident-forensics +39.4% | 100% |
| noisy-output | baseline | 6 | 204275 | 207076 | 176736–232003 | 176800–237352 | — | — | — | 100% |
| noisy-output | hush | 6 | 204209 | 215991 | 200034–216489 | 188272–243709 | -0.0% | 33% | log-triage +11.2% | 100% |
| search-heavy | baseline | 2 | 309739 | 309739 | 294025–325452 | 248141–371336 | — | — | — | 100% |
| search-heavy | hush | 2 | 390309 | 390309 | 337513–443104 | 183351–597266 | +26.0% | 0% | repo-sweep +26.0% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 12813 | 12894 | 10445–15261 | 9844–15943 | — | — | — | 100% |
| long-session | hush | 4 | 10678 | 10435 | 8314–12799 | 7608–13262 | -16.7% | 100% | — | 100% |
| noisy-output | baseline | 6 | 3943 | 4097 | 2791–4979 | 2699–5494 | — | — | — | 100% |
| noisy-output | hush | 6 | 2313 | 2291 | 1461–2369 | 1283–3300 | -41.3% | 100% | — | 100% |
| search-heavy | baseline | 2 | 5018 | 5018 | 4975–5061 | 4849–5187 | — | — | — | 100% |
| search-heavy | hush | 2 | 12004 | 12004 | 11825–12184 | 11300–12708 | +139.2% | 0% | repo-sweep +139.2% | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 35 | 34 | 8–61 | 3–65 | — | — | — | 100% |
| long-session | hush | 4 | 0 | 0 | 0–0 | 0–0 | -100.0% | 100% | — | 100% |
| noisy-output | baseline | 6 | 41 | 45 | 33–58 | 22–69 | — | — | — | 100% |
| noisy-output | hush | 6 | 0 | 2 | 0–5 | -1–5 | -100.0% | 100% | — | 100% |
| search-heavy | baseline | 2 | 79 | 79 | 75–83 | 63–95 | — | — | — | 100% |
| search-heavy | hush | 2 | 6 | 6 | 6–6 | 6–6 | -92.4% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3150 | 3943 (0%) | 204401 (0%) | 38 | 356 | 7111 | 11.5 |
| hush | 100% | 1.00 | 0.2953 | 2327 (-41%) | 200367 (-2%) | 4 | 70 | 6258 | 10.5 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2969 | 2341 (0%) | 196398 (0%) | 77 | 250 | 15283 | 11.5 |
| hush | 100% | 1.00 | 0.2960 | 1100 (-53%) | 202433 (+3%) | 0 | 60 | 15025 | 9.5 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.9904 | 10244 (0%) | 858640 (0%) | 35 | 210 | 19434 | 30.0 |
| hush | 100% | 1.00 | 0.8285 | 7984 (-22%) | 707015 (-18%) | 0 | 50 | 16183 | 23.5 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.9355 | 15544 (0%) | 551754 (0%) | 34 | 930 | 19369 | 17.5 |
| hush | 100% | 1.00 | 1.0138 | 12887 (-17%) | 769091 (+39%) | 0 | 101 | 19069 | 22.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.5283 | 6006 (0%) | 220429 (0%) | 22 | 809 | 37272 | 8.0 |
| hush | 100% | 0.83 | 0.3863 | 3447 (-43%) | 245172 (+11%) | 3 | 139 | 12894 | 8.5 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.5238 | 5018 (0%) | 309739 (0%) | 79 | 249 | 33063 | 14.0 |
| hush | 100% | 1.00 | 1.6747 | 12004 (+139%) | 390309 (+26%) | 6 | 53 | 47453 | 56.0 |
