# hush benchmark — run `pub0721b`

120 runs · model `sonnet` · generated from `results/pub0721b/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.1785 | 1564 | 185249 | 46 | 145 | 7.0 | 27 |
| **brief** | 100% | 0.1749 | 1171 | 176035 | 25 | 100 | 6.6 | 24 |
| **efficiency** | 100% | 0.1698 | 1031 | 172620 | 12 | 76 | 6.6 | 22 |
| **hush** | 100% | 0.1591 | 1366 | 166244 | 2 | 95 | 6.7 | 28 |

Deltas vs baseline — cost: brief -2%, efficiency -5%, hush -11%; output tokens: brief -25%, efficiency -34%, hush -13%; context traffic: brief -5%, efficiency -7%, hush -10%.

## bugfix-expiry

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1188 | 860 (0%) | 160994 (0%) | 50 | 45 | 2769 | 6.5 |
| brief | 100% | 1.00 | 0.1394 | 788 (-8%) | 200599 (+25%) | 26 | 18 | 3367 | 7.5 |
| efficiency | 100% | 1.00 | 0.1359 | 644 (-25%) | 177006 (+10%) | 15 | 13 | 2774 | 6.5 |
| hush | 100% | 1.00 | 0.1489 | 747 (-13%) | 196049 (+22%) | 0 | 34 | 2798 | 7.0 |

## bugfix-pagination

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1087 | 675 (0%) | 145222 (0%) | 25 | 37 | 2258 | 6.0 |
| brief | 100% | 1.00 | 0.1176 | 607 (-10%) | 152601 (+5%) | 17 | 20 | 2184 | 6.0 |
| efficiency | 100% | 1.00 | 0.1275 | 655 (-3%) | 159809 (+10%) | 16 | 21 | 1617 | 6.0 |
| hush | 100% | 1.00 | 0.1346 | 637 (-6%) | 162496 (+12%) | 8 | 31 | 2310 | 6.0 |

## checkout-bug

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1339 | 1223 (0%) | 165151 (0%) | 34 | 49 | 5004 | 9.0 |
| brief | 100% | 1.00 | 0.1367 | 1191 (-3%) | 156917 (-5%) | 23 | 24 | 4421 | 8.0 |
| efficiency | 100% | 1.00 | 0.1465 | 1155 (-6%) | 164171 (-1%) | 17 | 18 | 4425 | 8.0 |
| hush | 100% | 1.00 | 0.1751 | 1501 (+23%) | 203518 (+23%) | 0 | 49 | 5568 | 9.5 |

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2162 | 2951 (0%) | 260804 (0%) | 262 | 100 | 9898 | 11.0 |
| brief | 100% | 1.00 | 0.1651 | 1821 (-38%) | 193024 (-26%) | 144 | 87 | 5737 | 9.0 |
| efficiency | 100% | 1.00 | 0.1545 | 1185 (-60%) | 182066 (-30%) | 63 | 35 | 4907 | 8.0 |
| hush | 100% | 1.00 | 0.1906 | 1883 (-36%) | 209897 (-20%) | 0 | 122 | 7712 | 9.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1915 | 2047 (0%) | 228020 (0%) | 41 | 127 | 12456 | 10.5 |
| brief | 100% | 1.00 | 0.2187 | 1683 (-18%) | 280231 (+23%) | 40 | 60 | 15849 | 10.0 |
| efficiency | 100% | 1.00 | 0.1697 | 1563 (-24%) | 201361 (-12%) | 10 | 73 | 5835 | 9.0 |
| hush | 100% | 1.00 | 0.2109 | 1880 (-8%) | 276294 (+21%) | 0 | 92 | 7920 | 10.0 |

## explain-rebase

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0604 | 475 (0%) | 28178 (0%) | 0 | 226 | 0 | 1.0 |
| brief | 100% | 0.83 | 0.0666 | 314 (-34%) | 29713 (+5%) | 0 | 120 | 0 | 1.0 |
| efficiency | 100% | 1.00 | 0.0745 | 258 (-46%) | 31175 (+11%) | 0 | 99 | 0 | 1.0 |
| hush | 100% | 0.83 | 0.0770 | 312 (-34%) | 31362 (+11%) | 0 | 152 | 0 | 1.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0631 | 655 (0%) | 28177 (0%) | 0 | 257 | 0 | 1.0 |
| brief | 100% | 1.00 | 0.0687 | 455 (-31%) | 29712 (+5%) | 0 | 165 | 0 | 1.0 |
| efficiency | 100% | 0.83 | 0.0744 | 252 (-62%) | 31174 (+11%) | 0 | 101 | 0 | 1.0 |
| hush | 100% | 1.00 | 0.0819 | 638 (-3%) | 31361 (+11%) | 0 | 142 | 0 | 1.0 |

## incident-followup

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4272 | 3775 (0%) | 420270 (0%) | 0 | 281 | 61029 | 7.5 |
| brief | 100% | 1.00 | 0.4239 | 2778 (-26%) | 457506 (+9%) | 0 | 362 | 60591 | 8.0 |
| efficiency | 100% | 1.00 | 0.4140 | 2019 (-47%) | 436762 (+4%) | 0 | 190 | 60528 | 7.5 |
| hush | 100% | 1.00 | 0.2808 | 2948 (-22%) | 295522 (-30%) | 0 | 157 | 9709 | 8.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2832 | 2338 (0%) | 304547 (0%) | 132 | 150 | 33874 | 12.0 |
| brief | 100% | 1.00 | 0.2413 | 1499 (-36%) | 229801 (-25%) | 41 | 67 | 29716 | 10.0 |
| efficiency | 100% | 1.00 | 0.1994 | 1742 (-25%) | 272905 (-10%) | 34 | 71 | 7555 | 11.0 |
| hush | 100% | 1.00 | 0.1916 | 1530 (-35%) | 214208 (-30%) | 0 | 114 | 10301 | 9.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2944 | 1117 (0%) | 168707 (0%) | 0 | 309 | 60148 | 3.5 |
| brief | 100% | 1.00 | 0.2904 | 854 (-24%) | 143196 (-15%) | 0 | 224 | 60137 | 3.0 |
| efficiency | 100% | 1.00 | 0.3003 | 850 (-24%) | 147638 (-12%) | 0 | 207 | 60137 | 3.0 |
| hush | 100% | 1.00 | 0.1556 | 2050 (+84%) | 102433 (-39%) | 0 | 157 | 8723 | 3.0 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1780 | 1323 (0%) | 213857 (0%) | 69 | 81 | 14182 | 8.0 |
| brief | 100% | 1.00 | 0.1884 | 1069 (-19%) | 236832 (+11%) | 39 | 45 | 14193 | 8.0 |
| efficiency | 100% | 1.00 | 0.1480 | 784 (-41%) | 196811 (-8%) | 12 | 28 | 4180 | 7.0 |
| hush | 100% | 1.00 | 0.1647 | 1038 (-22%) | 202064 (-6%) | 0 | 81 | 6274 | 7.0 |

## refactor-rename

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2102 | 2489 (0%) | 324025 (0%) | 65 | 25 | 5530 | 14.5 |
| brief | 100% | 1.00 | 0.2048 | 2230 (-10%) | 290223 (-10%) | 44 | 18 | 5934 | 15.5 |
| efficiency | 100% | 1.00 | 0.2039 | 2174 (-13%) | 267650 (-17%) | 16 | 18 | 5510 | 15.0 |
| hush | 100% | 1.00 | 0.2143 | 2328 (-6%) | 259839 (-20%) | 23 | 39 | 5694 | 15.5 |

## repo-summary

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1220 | 1761 (0%) | 117111 (0%) | 16 | 375 | 4420 | 8.0 |
| brief | 100% | 1.00 | 0.1131 | 1239 (-30%) | 91719 (-22%) | 2 | 202 | 4107 | 7.0 |
| efficiency | 100% | 1.00 | 0.1354 | 1280 (-27%) | 128256 (+10%) | 3 | 192 | 4510 | 8.0 |
| hush | 100% | 1.00 | 0.1436 | 1890 (+7%) | 113567 (-3%) | 0 | 163 | 4378 | 7.5 |

## sidecar-follow

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1914 | 1153 (0%) | 142389 (0%) | 0 | 71 | 25121 | 4.0 |
| brief | 100% | 1.00 | 0.1748 | 617 (-46%) | 103639 (-27%) | 0 | 46 | 24928 | 3.0 |
| efficiency | 100% | 1.00 | 0.1757 | 660 (-43%) | 144427 (+1%) | 0 | 34 | 17699 | 5.5 |
| hush | 100% | 1.00 | 0.1403 | 820 (-29%) | 163705 (+15%) | 0 | 35 | 3066 | 5.0 |

## write-validator

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0788 | 619 (0%) | 71286 (0%) | 0 | 51 | 255 | 2.5 |
| brief | 100% | 1.00 | 0.0742 | 419 (-32%) | 44819 (-37%) | 3 | 46 | 85 | 1.5 |
| efficiency | 100% | 1.00 | 0.0870 | 248 (-60%) | 48091 (-33%) | 0 | 42 | 14 | 2.0 |
| hush | 100% | 1.00 | 0.0766 | 293 (-53%) | 31348 (-56%) | 0 | 53 | 0 | 1.0 |
