# hush benchmark — run `sn291`

32 runs · model `sonnet` · generated from `results/sn291/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Rubric coverage | Cost USD | Output tok | Context traffic tok | Narration words | Silent | One message | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 98% | 0.2612 | 5035 | 416228 | 37 | 25% | 19% | 195 | 15.1 | 65 |
| **hush** | 100% | 96% | 0.2463 | 4700 | 417946 | 12 | 69% | 56% | 87 | 16.0 | 61 |

Deltas vs baseline — cost: hush -6%; output tokens: hush -7%; context traffic: hush +0%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 0.2995 | 0.3093 | 0.2802–0.3285 | 0.2713–0.3473 | — | — | — | 100% |
| long-session | hush | 4 | 0.3067 | 0.3106 | 0.2317–0.3857 | 0.2007–0.4206 | +2.4% | 50% | feature-drift +35.3% | 100% |
| noisy-output | baseline | 8 | 0.2447 | 0.2653 | 0.1807–0.3210 | 0.1727–0.3579 | — | — | — | 100% |
| noisy-output | hush | 8 | 0.1818 | 0.2301 | 0.1332–0.2700 | 0.1395–0.3207 | -25.7% | 75% | dep-bump-warnings +5.9% | 100% |
| search-heavy | baseline | 4 | 0.1824 | 0.2049 | 0.1499–0.2375 | 0.1239–0.2859 | — | — | — | 100% |
| search-heavy | hush | 4 | 0.2179 | 0.2143 | 0.1418–0.2904 | 0.1273–0.3012 | +19.5% | 50% | repo-sweep +9.9% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 771432 | 742668 | 710014–804086 | 637147–848189 | — | — | — | 100% |
| long-session | hush | 4 | 809647 | 810297 | 540320–1079624 | 444893–1175701 | +5.0% | 50% | feature-drift +37.6% | 100% |
| noisy-output | baseline | 8 | 217805 | 316169 | 201655–317810 | 177992–454345 | — | — | — | 100% |
| noisy-output | hush | 8 | 252212 | 311831 | 226467–341032 | 188262–435401 | +15.8% | 75% | dep-bump-warnings +26.6% | 100% |
| search-heavy | baseline | 4 | 285063 | 289908 | 196415–378555 | 169802–410014 | — | — | — | 100% |
| search-heavy | hush | 4 | 230148 | 237823 | 170838–297134 | 159986–315660 | -19.3% | 100% | — | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 41023 | 43944 | 38921–46046 | 34631–53257 | — | — | — | 100% |
| long-session | hush | 4 | 38811 | 39276 | 37392–40695 | 36402–42150 | -5.4% | 50% | feature-drift +9.3% | 100% |
| noisy-output | baseline | 8 | 37177 | 40610 | 33397–45276 | 33927–47293 | — | — | — | 100% |
| noisy-output | hush | 8 | 35311 | 40115 | 34039–41911 | 33266–46964 | -5.0% | 25% | release-digest +9.9% | 100% |
| search-heavy | baseline | 4 | 35377 | 35648 | 34130–36896 | 33490–37806 | — | — | — | 100% |
| search-heavy | hush | 4 | 37309 | 37395 | 34168–40537 | 33547–41243 | +5.5% | 0% | repo-sweep +9.0% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 4485 | 4502 | 4210–4776 | 4001–5002 | — | — | — | 100% |
| long-session | hush | 4 | 4267 | 4520 | 2778–6009 | 2468–6572 | -4.9% | 50% | feature-drift +40.2% | 100% |
| noisy-output | baseline | 8 | 1715 | 4812 | 1483–4802 | 640–8984 | — | — | — | 100% |
| noisy-output | hush | 8 | 1701 | 3551 | 1599–4357 | 1252–5851 | -0.8% | 75% | log-triage +64.5% | 100% |
| search-heavy | baseline | 4 | 4830 | 6016 | 4036–6810 | 2923–9108 | — | — | — | 100% |
| search-heavy | hush | 4 | 7531 | 7179 | 4587–10122 | 3539–10818 | +55.9% | 0% | repo-sweep +27.5% | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 35 | 29 | 18–45 | 7–50 | — | — | — | 100% |
| long-session | hush | 4 | 22 | 30 | 0–52 | -6–66 | -36.2% | 50% | feature-drift +72.5% | 100% |
| noisy-output | baseline | 8 | 45 | 44 | 17–66 | 19–70 | — | — | — | 100% |
| noisy-output | hush | 8 | 0 | 6 | 0–4 | -2–13 | -100.0% | 100% | — | 100% |
| search-heavy | baseline | 4 | 37 | 30 | 24–43 | 10–50 | — | — | — | 100% |
| search-heavy | hush | 4 | 0 | 6 | 0–6 | -6–17 | -100.0% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1205 | 1948 (0%) | 198123 (0%) | 77 | 97 | 11471 | 10.0 |
| hush | 100% | 1.00 | 0.1276 | 1698 (-13%) | 250792 (+27%) | 0 | 80 | 7821 | 10.0 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1997 | 1409 (0%) | 232398 (0%) | 46 | 65 | 11687 | 10.0 |
| hush | 100% | 1.00 | 0.1657 | 1407 (-0%) | 224605 (-3%) | 8 | 41 | 11590 | 9.5 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2977 | 4485 (0%) | 815220 (0%) | 35 | 42 | 22329 | 24.5 |
| hush | 100% | 1.00 | 0.4028 | 6289 (+40%) | 1122039 (+38%) | 60 | 58 | 25136 | 29.0 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3209 | 4519 (0%) | 670117 (0%) | 23 | 246 | 43782 | 16.5 |
| hush | 100% | 1.00 | 0.2185 | 2751 (-39%) | 498556 (-26%) | 0 | 101 | 18692 | 13.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2881 | 1410 (0%) | 201146 (0%) | 0 | 352 | 60315 | 4.5 |
| hush | 100% | 1.00 | 0.1922 | 2319 (+64%) | 183921 (-9%) | 0 | 114 | 25712 | 5.0 |

## release-digest

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.83 | 0.4527 | 14483 (0%) | 633008 (0%) | 56 | 239 | 50777 | 14.5 |
| hush | 100% | 0.67 | 0.4349 | 8782 (-39%) | 588008 (-7%) | 15 | 114 | 83680 | 13.0 |

## rename-scope

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1451 | 3955 (0%) | 186698 (0%) | 23 | 427 | 15690 | 12.0 |
| hush | 100% | 1.00 | 0.1376 | 4060 (+3%) | 170087 (-9%) | 0 | 127 | 9100 | 12.0 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2648 | 8076 (0%) | 393118 (0%) | 37 | 96 | 22189 | 29.0 |
| hush | 100% | 1.00 | 0.2909 | 10298 (+28%) | 305560 (-22%) | 12 | 60 | 24977 | 36.0 |
