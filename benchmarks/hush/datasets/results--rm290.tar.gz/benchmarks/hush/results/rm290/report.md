# hush benchmark — run `rm290`

64 runs · model `opus` · generated from `results/rm290/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Rubric coverage | Cost USD | Output tok | Context traffic tok | Narration words | Silent | One message | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 100% | 0.4734 | 5327 | 322095 | 44 | 0% | 0% | 405 | 13.9 | 84 |
| **hush** | 94% | 94% | 0.4075 | 3505 | 302490 | 4 | 34% | 22% | 77 | 14.7 | 64 |

Deltas vs baseline — cost: hush -14%; output tokens: hush -34%; context traffic: hush -6%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 0.7541 | 0.7319 | 0.6293–0.8122 | 0.6471–0.8166 | — | — | — | 100% |
| long-session | hush | 8 | 0.5938 | 0.5928 | 0.5041–0.6610 | 0.5243–0.6613 | -21.3% | 50% | feature-drift +10.5% | 75% |
| noisy-output | baseline | 16 | 0.2756 | 0.3822 | 0.2458–0.4207 | 0.2712–0.4932 | — | — | — | 100% |
| noisy-output | hush | 16 | 0.2521 | 0.3021 | 0.2188–0.3368 | 0.2376–0.3666 | -8.5% | 75% | failing-suite +0.5% | 100% |
| search-heavy | baseline | 8 | 0.3847 | 0.3974 | 0.3668–0.4202 | 0.3558–0.4390 | — | — | — | 100% |
| search-heavy | hush | 8 | 0.3751 | 0.4331 | 0.3605–0.3989 | 0.3233–0.5430 | -2.5% | 50% | repo-sweep +7.5% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 541260 | 580006 | 509308–593521 | 492847–667166 | — | — | — | 100% |
| long-session | hush | 8 | 564457 | 554189 | 397113–675354 | 434134–674243 | +4.3% | 50% | feature-drift +14.1% | 75% |
| noisy-output | baseline | 16 | 204011 | 236634 | 162062–256820 | 188077–285190 | — | — | — | 100% |
| noisy-output | hush | 16 | 188597 | 206449 | 171611–208283 | 177203–235696 | -7.6% | 75% | failing-suite +5.9% | 100% |
| search-heavy | baseline | 8 | 234654 | 235106 | 206323–270100 | 208372–261839 | — | — | — | 100% |
| search-heavy | hush | 8 | 226278 | 242874 | 211084–243833 | 200744–285003 | -3.6% | 50% | repo-sweep +6.5% | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 30529 | 30595 | 29763–31308 | 29730–31460 | — | — | — | 100% |
| long-session | hush | 8 | 30438 | 30275 | 28904–31407 | 29391–31160 | -0.3% | 50% | feature-drift +6.0% | 75% |
| noisy-output | baseline | 16 | 26781 | 30470 | 25542–29308 | 26454–34487 | — | — | — | 100% |
| noisy-output | hush | 16 | 28568 | 29584 | 27169–29936 | 27967–31200 | +6.7% | 25% | log-triage +7.0% | 100% |
| search-heavy | baseline | 8 | 29835 | 29785 | 29223–30073 | 29127–30444 | — | — | — | 100% |
| search-heavy | hush | 8 | 31911 | 33244 | 30982–33755 | 30390–36097 | +7.0% | 0% | repo-sweep +12.3% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 9026 | 9447 | 5858–11960 | 6716–12178 | — | — | — | 100% |
| long-session | hush | 8 | 5465 | 5560 | 5343–5741 | 5273–5846 | -39.5% | 100% | — | 75% |
| noisy-output | baseline | 16 | 2956 | 3619 | 2120–4778 | 2731–4507 | — | — | — | 100% |
| noisy-output | hush | 16 | 1658 | 2149 | 1245–2561 | 1567–2731 | -43.9% | 100% | — | 100% |
| search-heavy | baseline | 8 | 4187 | 4624 | 3536–5389 | 3573–5675 | — | — | — | 100% |
| search-heavy | hush | 8 | 3164 | 4163 | 3037–3514 | 2205–6121 | -24.4% | 100% | — | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 25 | 23 | 17–29 | 17–28 | — | — | — | 100% |
| long-session | hush | 8 | 3 | 3 | 0–6 | 1–6 | -89.8% | 100% | — | 75% |
| noisy-output | baseline | 16 | 42 | 56 | 27–85 | 32–80 | — | — | — | 100% |
| noisy-output | hush | 16 | 6 | 5 | 0–7 | 3–6 | -85.7% | 100% | — | 100% |
| search-heavy | baseline | 8 | 42 | 40 | 27–56 | 26–55 | — | — | — | 100% |
| search-heavy | hush | 8 | 6 | 5 | 4–7 | 3–7 | -85.7% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2292 | 2460 (0%) | 184328 (0%) | 35 | 286 | 6272 | 10.8 |
| hush | 100% | 1.00 | 0.2175 | 1747 (-29%) | 175628 (-5%) | 7 | 72 | 6744 | 10.0 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2447 | 1691 (0%) | 176863 (0%) | 88 | 159 | 12721 | 10.3 |
| hush | 100% | 1.00 | 0.2398 | 1119 (-34%) | 178836 (+1%) | 3 | 46 | 12218 | 9.8 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.6542 | 6160 (0%) | 658257 (0%) | 24 | 130 | 12598 | 25.0 |
| hush | 100% | 1.00 | 0.6781 | 5486 (-11%) | 707140 (+7%) | 5 | 62 | 11675 | 25.5 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.8096 | 12734 (0%) | 501756 (0%) | 21 | 768 | 16401 | 16.5 |
| hush | 50% | 0.67 | 0.5076 | 5633 (-56%) | 401238 (-20%) | 1 | 65 | 7477 | 14.8 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3073 | 4348 (0%) | 195504 (0%) | 12 | 641 | 9988 | 8.3 |
| hush | 100% | 0.83 | 0.2362 | 1664 (-62%) | 174141 (-11%) | 2 | 115 | 11990 | 7.5 |

## release-digest

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.7477 | 5978 (0%) | 389839 (0%) | 89 | 437 | 65027 | 10.3 |
| hush | 100% | 1.00 | 0.5149 | 4066 (-32%) | 297193 (-24%) | 8 | 96 | 33781 | 11.5 |

## rename-scope

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4316 | 5768 (0%) | 242923 (0%) | 28 | 621 | 17353 | 17.8 |
| hush | 100% | 1.00 | 0.3776 | 3437 (-40%) | 218401 (-10%) | 5 | 108 | 18217 | 17.0 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3631 | 3480 (0%) | 227288 (0%) | 53 | 202 | 17146 | 12.8 |
| hush | 100% | 1.00 | 0.4887 | 4889 (+40%) | 267346 (+18%) | 5 | 52 | 24666 | 21.8 |
