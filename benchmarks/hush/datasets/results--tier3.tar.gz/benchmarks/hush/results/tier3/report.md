# hush benchmark — run `tier3`

64 runs · model `sonnet` · generated from `results/tier3/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.2122 | 1698 | 189967 | 31 | 184 | 6.4 | 29 |
| **hush** | 100% | 0.1632 | 1425 | 174811 | 20 | 129 | 6.4 | 30 |

Deltas vs baseline — cost: hush -23%; output tokens: hush -16%; context traffic: hush -8%.

## bugfix-expiry

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2058 | 823 (0%) | 161375 (0%) | 45 | 42 | 2484 | 6.5 |
| hush | 100% | 1.00 | 0.1597 | 797 (-3%) | 164279 (+2%) | 34 | 45 | 2441 | 6.3 |
  - hush decisions (hush): passthrough:8, scrub-only:7

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0644 | 632 (0%) | 28355 (0%) | 0 | 225 | 0 | 1.0 |
| hush | 100% | 0.92 | 0.0764 | 480 (-24%) | 37944 (+34%) | 0 | 161 | 4 | 1.3 |

## incident-followup

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4370 | 3732 (0%) | 451244 (0%) | 5 | 232 | 60661 | 8.3 |
| hush | 100% | 1.00 | 0.2704 | 2834 (-24%) | 319857 (-29%) | 21 | 168 | 9373 | 9.0 |
  - hush decisions (hush): sidecar:8, passthrough:2

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2796 | 2078 (0%) | 282203 (0%) | 110 | 139 | 36318 | 11.3 |
| hush | 100% | 1.00 | 0.2036 | 1774 (-15%) | 250399 (-11%) | 70 | 116 | 12626 | 10.5 |
  - hush decisions (hush): passthrough:16, sidecar:3, scrub-only:12

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3096 | 2156 (0%) | 160796 (0%) | 6 | 368 | 60205 | 3.8 |
| hush | 100% | 1.00 | 0.1738 | 2251 (+4%) | 150936 (-6%) | 3 | 205 | 9439 | 4.5 |
  - hush decisions (hush): sidecar:8, passthrough:3

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1726 | 1483 (0%) | 202562 (0%) | 68 | 78 | 11845 | 8.0 |
| hush | 100% | 1.00 | 0.1822 | 1330 (-10%) | 256020 (+26%) | 22 | 85 | 7599 | 8.8 |
  - hush decisions (hush): passthrough:8, shell-guard-skip:6, template-collapse:1, scrub-only:9

## repo-summary

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1254 | 1841 (0%) | 117006 (0%) | 12 | 321 | 4502 | 8.0 |
| hush | 100% | 1.00 | 0.1284 | 1350 (-27%) | 117396 (+0%) | 8 | 216 | 4293 | 7.8 |
  - hush decisions (hush): scrub-only:4, passthrough:20

## sidecar-follow

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1035 | 840 (0%) | 116194 (0%) | 0 | 64 | 1898 | 4.3 |
| hush | 100% | 1.00 | 0.1109 | 581 (-31%) | 101659 (-13%) | 0 | 36 | 3473 | 3.5 |
  - hush decisions (hush): passthrough:5
