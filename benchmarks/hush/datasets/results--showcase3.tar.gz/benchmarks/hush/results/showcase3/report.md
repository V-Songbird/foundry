# hush benchmark — run `showcase3`

90 runs · model `haiku` · generated from `results/showcase3/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.0398 | 1217 | 87657 | 25 | 211 | 5.1 | 20 |
| **caveman** | 100% | 0.0393 | 1056 | 80909 | 11 | 138 | 4.5 | 20 |
| **hush** | 97% | 0.0393 | 1066 | 91514 | 6 | 154 | 4.6 | 21 |

Deltas vs baseline — cost: caveman -1%, hush -1%; output tokens: caveman -13%, hush -12%; context traffic: caveman -8%, hush +4%.

## bugfix-expiry

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0465 | 1933 (0%) | 176904 (0%) | 105 | 90 | 3733 | 9.3 |
| caveman | 100% | 1.00 | 0.0461 | 1661 (-14%) | 187110 (+6%) | 50 | 42 | 2633 | 9.2 |
| hush | 100% | 1.00 | 0.0486 | 1664 (-14%) | 197175 (+11%) | 26 | 24 | 3125 | 9.3 |

## explain-rebase

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.94 | 0.0177 | 610 (0%) | 21377 (0%) | 0 | 242 | 0 | 1.0 |
| caveman | 100% | 0.89 | 0.0187 | 511 (-16%) | 22419 (+5%) | 0 | 169 | 0 | 1.0 |
| hush | 100% | 1.00 | 0.0206 | 691 (+13%) | 22631 (+6%) | 0 | 232 | 0 | 1.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.72 | 0.0192 | 740 (0%) | 28601 (0%) | 2 | 196 | 9 | 1.3 |
| caveman | 100% | 0.72 | 0.0188 | 531 (-28%) | 22420 (-22%) | 0 | 141 | 0 | 1.0 |
| hush | 83% | 0.72 | 0.0201 | 598 (-19%) | 22632 (-21%) | 0 | 158 | 0 | 1.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0749 | 1146 (0%) | 68950 (0%) | 4 | 232 | 60098 | 2.0 |
| caveman | 100% | 1.00 | 0.0764 | 1108 (-3%) | 71101 (+3%) | 1 | 172 | 60098 | 2.0 |
| hush | 100% | 1.00 | 0.0643 | 823 (-28%) | 65642 (-5%) | 0 | 150 | 48014 | 2.0 |

## repo-summary

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0409 | 1657 (0%) | 142455 (0%) | 14 | 294 | 4551 | 11.8 |
| caveman | 100% | 1.00 | 0.0368 | 1469 (-11%) | 101494 (-29%) | 4 | 168 | 4381 | 9.3 |
| hush | 100% | 1.00 | 0.0430 | 1554 (-6%) | 149489 (+5%) | 2 | 204 | 4547 | 9.7 |
