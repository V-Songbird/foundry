# hush benchmark — run `sonnet-showcase-smoke`

18 runs · model `sonnet` · generated from `results/sonnet-showcase-smoke/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.2589 | 1958 | 253861 | 44 | 202 | 9.0 | 37 |
| **caveman** | 100% | 0.2189 | 1274 | 204304 | 29 | 68 | 7.8 | 28 |
| **hush** | 100% | 0.2361 | 1454 | 235180 | 34 | 104 | 8.2 | 30 |

Deltas vs baseline — cost: caveman -15%, hush -9%; output tokens: caveman -35%, hush -26%; context traffic: caveman -20%, hush -7%.

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2972 | 3128 (0%) | 374148 (0%) | 15 | 177 | 21460 | 14.0 |
| caveman | 100% | 1.00 | 0.2855 | 2393 (-23%) | 389132 (+4%) | 106 | 6 | 15353 | 14.0 |
| hush | 100% | 1.00 | 0.2205 | 1865 (-40%) | 245493 (-34%) | 103 | 90 | 14848 | 10.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2407 | 2407 (0%) | 386877 (0%) | 59 | 117 | 7890 | 14.0 |
| caveman | 100% | 1.00 | 0.1992 | 1912 (-21%) | 234530 (-39%) | 7 | 75 | 5875 | 12.0 |
| hush | 100% | 1.00 | 0.2157 | 1956 (-19%) | 301749 (-22%) | 32 | 76 | 7122 | 11.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0578 | 724 (0%) | 28336 (0%) | 0 | 287 | 0 | 1.0 |
| caveman | 100% | 0.67 | 0.0572 | 242 (-67%) | 30757 (+9%) | 0 | 95 | 0 | 1.0 |
| hush | 100% | 1.00 | 0.0642 | 412 (-43%) | 30294 (+7%) | 0 | 144 | 0 | 1.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3592 | 2354 (0%) | 318695 (0%) | 136 | 131 | 54136 | 12.0 |
| caveman | 100% | 1.00 | 0.1593 | 1260 (-46%) | 162535 (-49%) | 38 | 39 | 4884 | 8.0 |
| hush | 100% | 1.00 | 0.3239 | 1675 (-29%) | 352923 (+11%) | 62 | 98 | 40782 | 12.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2989 | 1531 (0%) | 139042 (0%) | 16 | 398 | 60384 | 3.0 |
| caveman | 100% | 1.00 | 0.3094 | 774 (-49%) | 146287 (+5%) | 0 | 164 | 60384 | 3.0 |
| hush | 100% | 1.00 | 0.3019 | 1773 (+16%) | 223366 (+61%) | 0 | 165 | 48521 | 6.0 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2994 | 1602 (0%) | 276070 (0%) | 36 | 103 | 5169 | 10.0 |
| caveman | 100% | 1.00 | 0.3025 | 1065 (-34%) | 262582 (-5%) | 21 | 31 | 4338 | 9.0 |
| hush | 100% | 1.00 | 0.2906 | 1041 (-35%) | 257254 (-7%) | 7 | 48 | 4280 | 9.0 |
