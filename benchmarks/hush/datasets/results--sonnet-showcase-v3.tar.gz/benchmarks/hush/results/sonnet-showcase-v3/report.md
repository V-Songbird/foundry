# hush benchmark — run `sonnet-showcase-v3`

18 runs · model `sonnet` · generated from `results/sonnet-showcase-v3/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.2244 | 1701 | 214223 | 77 | 175 | 8.0 | 30 |
| **caveman** | 100% | 0.2005 | 1235 | 175764 | 28 | 106 | 6.5 | 22 |
| **hush** | 100% | 0.2060 | 1440 | 208377 | 30 | 101 | 7.3 | 29 |

Deltas vs baseline — cost: caveman -11%, hush -8%; output tokens: caveman -27%, hush -15%; context traffic: caveman -18%, hush -3%.

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2252 | 2493 (0%) | 298375 (0%) | 268 | 77 | 9913 | 12.0 |
| caveman | 100% | 1.00 | 0.1959 | 1807 (-28%) | 233697 (-22%) | 97 | 76 | 5641 | 9.0 |
| hush | 100% | 1.00 | 0.1794 | 1970 (-21%) | 197519 (-34%) | 90 | 99 | 5502 | 9.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2313 | 1902 (0%) | 306384 (0%) | 43 | 144 | 16286 | 11.0 |
| caveman | 100% | 1.00 | 0.2159 | 1888 (-1%) | 270005 (-12%) | 26 | 84 | 8337 | 10.0 |
| hush | 100% | 1.00 | 0.2224 | 1830 (-4%) | 329082 (+7%) | 10 | 86 | 8044 | 10.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0566 | 644 (0%) | 28334 (0%) | 0 | 240 | 0 | 1.0 |
| caveman | 100% | 1.00 | 0.0564 | 185 (-71%) | 30755 (+9%) | 0 | 70 | 0 | 1.0 |
| hush | 100% | 0.67 | 0.0932 | 624 (-3%) | 60838 (+115%) | 0 | 160 | 14 | 2.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3284 | 2000 (0%) | 257856 (0%) | 105 | 113 | 52381 | 11.0 |
| caveman | 100% | 1.00 | 0.1574 | 1197 (-40%) | 162260 (-37%) | 24 | 69 | 4881 | 8.0 |
| hush | 100% | 1.00 | 0.2720 | 1927 (-4%) | 319303 (+24%) | 65 | 73 | 26087 | 13.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3154 | 1429 (0%) | 196323 (0%) | 0 | 388 | 60404 | 5.0 |
| caveman | 100% | 1.00 | 0.3132 | 1043 (-27%) | 146240 (-26%) | 0 | 278 | 60389 | 3.0 |
| hush | 100% | 1.00 | 0.2677 | 1483 (+4%) | 130927 (-33%) | 0 | 145 | 48439 | 3.0 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1897 | 1738 (0%) | 198067 (0%) | 48 | 85 | 14340 | 8.0 |
| caveman | 100% | 1.00 | 0.2642 | 1288 (-26%) | 211624 (+7%) | 22 | 58 | 34146 | 8.0 |
| hush | 100% | 1.00 | 0.2016 | 803 (-54%) | 212590 (+7%) | 13 | 43 | 19193 | 7.0 |
