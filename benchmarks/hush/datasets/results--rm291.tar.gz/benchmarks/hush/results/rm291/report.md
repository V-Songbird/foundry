# hush benchmark — run `rm291`

64 runs · model `opus` · generated from `results/rm291/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Rubric coverage | Cost USD | Output tok | Context traffic tok | Narration words | Silent | One message | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 100% | 0.5246 | 5369 | 348005 | 23 | 0% | 0% | 421 | 15.6 | 83 |
| **hush** | 100% | 98% | 0.4196 | 3489 | 302281 | 4 | 34% | 19% | 78 | 14.6 | 62 |

Deltas vs baseline — cost: hush -20%; output tokens: hush -35%; context traffic: hush -13%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 0.8057 | 0.8132 | 0.7575–0.8576 | 0.7408–0.8856 | — | — | — | 100% |
| long-session | hush | 8 | 0.5775 | 0.5981 | 0.5527–0.6490 | 0.5485–0.6477 | -28.3% | 100% | — | 100% |
| noisy-output | baseline | 16 | 0.3305 | 0.4247 | 0.2601–0.5637 | 0.3290–0.5205 | — | — | — | 100% |
| noisy-output | hush | 16 | 0.2808 | 0.3203 | 0.2597–0.3752 | 0.2774–0.3632 | -15.0% | 75% | failing-suite +8.9% | 100% |
| search-heavy | baseline | 8 | 0.3942 | 0.4357 | 0.3333–0.4374 | 0.3216–0.5497 | — | — | — | 100% |
| search-heavy | hush | 8 | 0.4235 | 0.4396 | 0.3535–0.4546 | 0.3272–0.5520 | +7.4% | 50% | repo-sweep +30.4% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 708016 | 672498 | 516506–825920 | 539798–805197 | — | — | — | 100% |
| long-session | hush | 8 | 546724 | 566823 | 456299–689009 | 469578–664068 | -22.8% | 100% | — | 100% |
| noisy-output | baseline | 16 | 221681 | 239938 | 185728–273890 | 199766–280110 | — | — | — | 100% |
| noisy-output | hush | 16 | 196895 | 203766 | 184620–217519 | 187447–220086 | -11.2% | 75% | dep-bump-warnings +14.3% | 100% |
| search-heavy | baseline | 8 | 232753 | 239647 | 223330–246868 | 204267–275028 | — | — | — | 100% |
| search-heavy | hush | 8 | 215250 | 234769 | 198830–280905 | 186396–283143 | -7.5% | 50% | repo-sweep +3.8% | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 31205 | 32158 | 30332–32486 | 30294–34022 | — | — | — | 100% |
| long-session | hush | 8 | 30599 | 30699 | 30268–31319 | 30141–31257 | -1.9% | 50% | feature-drift +1.9% | 100% |
| noisy-output | baseline | 16 | 27710 | 32497 | 25519–40247 | 28438–36555 | — | — | — | 100% |
| noisy-output | hush | 16 | 28715 | 29550 | 27130–31686 | 28235–30865 | +3.6% | 50% | failing-suite +10.8% | 100% |
| search-heavy | baseline | 8 | 29292 | 30215 | 28802–29920 | 27977–32452 | — | — | — | 100% |
| search-heavy | hush | 8 | 33135 | 33132 | 30596–35041 | 30472–35792 | +13.1% | 0% | repo-sweep +18.8% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 8762 | 9795 | 7401–11919 | 7731–11859 | — | — | — | 100% |
| long-session | hush | 8 | 5543 | 5335 | 5145–5680 | 4964–5705 | -36.7% | 100% | — | 100% |
| noisy-output | baseline | 16 | 2827 | 3072 | 2322–3762 | 2458–3685 | — | — | — | 100% |
| noisy-output | hush | 16 | 1755 | 2097 | 1364–2417 | 1620–2574 | -37.9% | 100% | — | 100% |
| search-heavy | baseline | 8 | 5006 | 5538 | 3313–6125 | 3240–7835 | — | — | — | 100% |
| search-heavy | hush | 8 | 3771 | 4427 | 2534–4614 | 2404–6450 | -24.7% | 50% | repo-sweep +19.1% | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 19 | 19 | 15–23 | 14–23 | — | — | — | 100% |
| long-session | hush | 8 | 0 | 2 | 0–5 | 0–4 | -100.0% | 100% | — | 100% |
| noisy-output | baseline | 16 | 24 | 25 | 17–32 | 18–33 | — | — | — | 100% |
| noisy-output | hush | 16 | 6 | 4 | 0–7 | 2–6 | -75.0% | 100% | — | 100% |
| search-heavy | baseline | 8 | 20 | 21 | 9–31 | 12–30 | — | — | — | 100% |
| search-heavy | hush | 8 | 6 | 7 | 6–8 | 6–7 | -70.0% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2654 | 2695 (0%) | 178948 (0%) | 30 | 286 | 7679 | 10.3 |
| hush | 100% | 1.00 | 0.2544 | 1691 (-37%) | 189260 (+6%) | 7 | 75 | 6453 | 10.0 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2487 | 1690 (0%) | 190718 (0%) | 36 | 187 | 9448 | 9.5 |
| hush | 100% | 1.00 | 0.2701 | 1237 (-27%) | 188937 (-1%) | 4 | 44 | 13081 | 10.0 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.8024 | 7311 (0%) | 837450 (0%) | 15 | 154 | 14102 | 30.3 |
| hush | 100% | 1.00 | 0.6555 | 5061 (-31%) | 690136 (-18%) | 2 | 54 | 11764 | 24.8 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.8241 | 12280 (0%) | 507546 (0%) | 23 | 802 | 21590 | 16.0 |
| hush | 100% | 1.00 | 0.5408 | 5608 (-54%) | 443511 (-13%) | 3 | 75 | 9560 | 16.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.5064 | 3171 (0%) | 226358 (0%) | 10 | 654 | 49717 | 7.3 |
| hush | 100% | 0.83 | 0.2966 | 1804 (-43%) | 193056 (-15%) | 3 | 119 | 13672 | 7.3 |

## release-digest

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.6784 | 4732 (0%) | 363729 (0%) | 26 | 474 | 62329 | 9.8 |
| hush | 100% | 1.00 | 0.4602 | 3658 (-23%) | 243813 (-33%) | 4 | 94 | 32120 | 10.0 |

## rename-scope

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4134 | 5573 (0%) | 224186 (0%) | 24 | 643 | 17221 | 18.5 |
| hush | 100% | 1.00 | 0.3589 | 3584 (-36%) | 204853 (-9%) | 7 | 103 | 16436 | 17.0 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4579 | 5502 (0%) | 255109 (0%) | 18 | 169 | 19376 | 23.3 |
| hush | 100% | 1.00 | 0.5203 | 5270 (-4%) | 264686 (+4%) | 7 | 60 | 28457 | 21.3 |
