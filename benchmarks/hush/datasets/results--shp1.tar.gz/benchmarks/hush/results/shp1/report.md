# hush benchmark — run `shp1`

12 runs · model `opus` · generated from `results/shp1/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Rubric coverage | Cost USD | Output tok | Context traffic tok | Narration words | Silent | One message | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **askless** | 100% | 100% | 0.3618 | 2284 | 195510 | 5 | 25% | — | 64 | 12.3 | 39 |
| **shape** | 100% | 100% | 0.3496 | 2133 | 182441 | 2 | 75% | — | 60 | 12.3 | 38 |
| **shapeplus** | 100% | 100% | 0.4087 | 2985 | 241266 | 5 | 25% | — | 76 | 14.5 | 52 |

Deltas vs baseline — cost: askless —, shape —, shapeplus —; output tokens: askless —, shape —, shapeplus —; context traffic: askless —, shape —, shapeplus —.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| noisy-output | askless | 2 | 0.3379 | 0.3379 | 0.2993–0.3765 | 0.1866–0.4893 | — | — | — | 100% |
| noisy-output | shape | 2 | 0.3235 | 0.3235 | 0.2857–0.3613 | 0.1754–0.4716 | — | — | — | 100% |
| noisy-output | shapeplus | 2 | 0.3556 | 0.3556 | 0.3183–0.3930 | 0.2092–0.5021 | — | — | — | 100% |
| search-heavy | askless | 2 | 0.3856 | 0.3856 | 0.3470–0.4241 | 0.2344–0.5367 | — | — | — | 100% |
| search-heavy | shape | 2 | 0.3758 | 0.3758 | 0.3740–0.3776 | 0.3689–0.3827 | — | — | — | 100% |
| search-heavy | shapeplus | 2 | 0.4619 | 0.4619 | 0.4573–0.4664 | 0.4439–0.4798 | — | — | — | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| noisy-output | askless | 2 | 180820 | 180820 | 176635–185004 | 164415–197224 | — | — | — | 100% |
| noisy-output | shape | 2 | 166237 | 166237 | 164023–168450 | 157561–174912 | — | — | — | 100% |
| noisy-output | shapeplus | 2 | 196893 | 196893 | 193635–200151 | 184122–209664 | — | — | — | 100% |
| search-heavy | askless | 2 | 210200 | 210200 | 177129–243272 | 80560–339840 | — | — | — | 100% |
| search-heavy | shape | 2 | 198646 | 198646 | 194644–202648 | 182958–214334 | — | — | — | 100% |
| search-heavy | shapeplus | 2 | 285640 | 285640 | 271591–299688 | 230570–340709 | — | — | — | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| noisy-output | askless | 2 | 27884 | 27884 | 27456–28313 | 26204–29565 | — | — | — | 100% |
| noisy-output | shape | 2 | 27706 | 27706 | 27337–28075 | 26260–29152 | — | — | — | 100% |
| noisy-output | shapeplus | 2 | 28128 | 28128 | 27662–28593 | 26303–29952 | — | — | — | 100% |
| search-heavy | askless | 2 | 31677 | 31677 | 30244–33110 | 26060–37294 | — | — | — | 100% |
| search-heavy | shape | 2 | 33108 | 33108 | 32441–33775 | 30493–35722 | — | — | — | 100% |
| search-heavy | shapeplus | 2 | 34083 | 34083 | 32728–35437 | 28773–39393 | — | — | — | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| noisy-output | askless | 2 | 1436 | 1436 | 1344–1527 | 1078–1793 | — | — | — | 100% |
| noisy-output | shape | 2 | 1273 | 1273 | 1155–1391 | 810–1736 | — | — | — | 100% |
| noisy-output | shapeplus | 2 | 1691 | 1691 | 1565–1816 | 1200–2181 | — | — | — | 100% |
| search-heavy | askless | 2 | 3133 | 3133 | 2916–3349 | 2285–3980 | — | — | — | 100% |
| search-heavy | shape | 2 | 2994 | 2994 | 2744–3243 | 2014–3973 | — | — | — | 100% |
| search-heavy | shapeplus | 2 | 4280 | 4280 | 3758–4801 | 2236–6323 | — | — | — | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| noisy-output | askless | 2 | 7 | 7 | 7–7 | 7–7 | — | — | — | 100% |
| noisy-output | shape | 2 | 4 | 4 | 2–5 | -3–10 | — | — | — | 100% |
| noisy-output | shapeplus | 2 | 6 | 6 | 6–6 | 6–6 | — | — | — | 100% |
| search-heavy | askless | 2 | 3 | 3 | 2–5 | -3–9 | — | — | — | 100% |
| search-heavy | shape | 2 | 0 | 0 | 0–0 | 0–0 | — | — | — | 100% |
| search-heavy | shapeplus | 2 | 4 | 4 | 2–6 | -4–12 | — | — | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| askless | 100% | 1.00 | 0.4152 | 1618 (—) | 189189 (—) | 7 | 70 | 6494 | 10.0 |
| shape | 100% | 1.00 | 0.3990 | 1509 (—) | 161810 (—) | 7 | 59 | 6843 | 10.0 |
| shapeplus | 100% | 1.00 | 0.4304 | 1941 (—) | 190377 (—) | 6 | 77 | 7296 | 10.0 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| askless | 100% | 1.00 | 0.2607 | 1253 (—) | 172450 (—) | 7 | 49 | 12522 | 10.0 |
| shape | 100% | 1.00 | 0.2479 | 1037 (—) | 170663 (—) | 0 | 39 | 11928 | 10.0 |
| shapeplus | 100% | 1.00 | 0.2809 | 1440 (—) | 203409 (—) | 6 | 49 | 11951 | 11.0 |

## rename-scope

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| askless | 100% | 1.00 | 0.3084 | 2700 (—) | 144057 (—) | 0 | 92 | 18801 | 15.0 |
| shape | 100% | 1.00 | 0.3723 | 3493 (—) | 190642 (—) | 0 | 98 | 20347 | 17.0 |
| shapeplus | 100% | 1.00 | 0.4710 | 5322 (—) | 313736 (—) | 8 | 101 | 15037 | 22.0 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| askless | 100% | 1.00 | 0.4627 | 3565 (—) | 276343 (—) | 6 | 43 | 28303 | 14.0 |
| shape | 100% | 1.00 | 0.3793 | 2494 (—) | 206650 (—) | 0 | 42 | 25286 | 12.0 |
| shapeplus | 100% | 1.00 | 0.4527 | 3237 (—) | 257543 (—) | 0 | 77 | 29523 | 15.0 |
