# hush benchmark — run `rm293`

64 runs · model `opus` · generated from `results/rm293/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Rubric coverage | Cost USD | Output tok | Context traffic tok | Narration words | Silent | One message | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 100% | 0.5015 | 5369 | 331025 | 26 | 0% | 0% | 428 | 15.4 | 83 |
| **hush** | 100% | 99% | 0.4391 | 3735 | 311844 | 3 | 59% | 38% | 76 | 16.8 | 64 |

Deltas vs baseline — cost: hush -12%; output tokens: hush -30%; context traffic: hush -6%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 0.7071 | 0.7361 | 0.6743–0.7281 | 0.6592–0.8130 | — | — | — | 100% |
| long-session | hush | 8 | 0.6008 | 0.5994 | 0.5070–0.6576 | 0.5003–0.6985 | -15.0% | 50% | feature-drift +3.7% | 100% |
| noisy-output | baseline | 16 | 0.3042 | 0.4025 | 0.2636–0.5524 | 0.3086–0.4964 | — | — | — | 100% |
| noisy-output | hush | 16 | 0.2748 | 0.3397 | 0.2516–0.3942 | 0.2809–0.3985 | -9.7% | 100% | — | 100% |
| search-heavy | baseline | 8 | 0.4283 | 0.4650 | 0.3604–0.5185 | 0.3567–0.5734 | — | — | — | 100% |
| search-heavy | hush | 8 | 0.4207 | 0.4776 | 0.3176–0.5428 | 0.3337–0.6216 | -1.8% | 50% | repo-sweep +34.8% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 648420 | 598009 | 462000–666552 | 503167–692851 | — | — | — | 100% |
| long-session | hush | 8 | 575326 | 571878 | 395715–715605 | 426555–717201 | -11.3% | 50% | feature-drift +11.5% | 100% |
| noisy-output | baseline | 16 | 193366 | 229123 | 180203–254278 | 190713–267533 | — | — | — | 100% |
| noisy-output | hush | 16 | 191382 | 212679 | 171587–248383 | 187633–237725 | -1.0% | 50% | log-triage +3.9% | 100% |
| search-heavy | baseline | 8 | 262346 | 267844 | 216971–314946 | 217916–317771 | — | — | — | 100% |
| search-heavy | hush | 8 | 259565 | 250137 | 198063–289985 | 207940–292334 | -1.1% | 50% | repo-sweep +1.8% | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 30580 | 31747 | 29965–31946 | 29757–33736 | — | — | — | 100% |
| long-session | hush | 8 | 30248 | 30265 | 29273–31205 | 29122–31408 | -1.1% | 50% | feature-drift +5.2% | 100% |
| noisy-output | baseline | 16 | 26684 | 30876 | 25846–35533 | 27176–34577 | — | — | — | 100% |
| noisy-output | hush | 16 | 28589 | 30063 | 27573–31351 | 28414–31713 | +7.1% | 25% | log-triage +11.5% | 100% |
| search-heavy | baseline | 8 | 29849 | 31228 | 29152–32114 | 28635–33821 | — | — | — | 100% |
| search-heavy | hush | 8 | 33013 | 33665 | 29339–36201 | 30318–37012 | +10.6% | 0% | repo-sweep +13.3% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 8186 | 8753 | 6659–10459 | 6930–10576 | — | — | — | 100% |
| long-session | hush | 8 | 5349 | 5362 | 4566–6033 | 4728–5996 | -34.7% | 100% | — | 100% |
| noisy-output | baseline | 16 | 3042 | 3522 | 2069–4705 | 2659–4385 | — | — | — | 100% |
| noisy-output | hush | 16 | 1803 | 2206 | 1492–2341 | 1622–2789 | -40.7% | 100% | — | 100% |
| search-heavy | baseline | 8 | 4816 | 5681 | 3974–6116 | 3637–7724 | — | — | — | 100% |
| search-heavy | hush | 8 | 2799 | 5165 | 2481–6817 | 2319–8010 | -41.9% | 50% | repo-sweep +65.5% | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 8 | 11 | 12 | 7–18 | 8–16 | — | — | — | 100% |
| long-session | hush | 8 | 0 | 1 | 0–0 | -1–2 | -100.0% | 100% | — | 100% |
| noisy-output | baseline | 16 | 28 | 31 | 20–40 | 21–40 | — | — | — | 100% |
| noisy-output | hush | 16 | 0 | 3 | 0–7 | 1–5 | -100.0% | 100% | — | 100% |
| search-heavy | baseline | 8 | 25 | 32 | 22–33 | 18–46 | — | — | — | 100% |
| search-heavy | hush | 8 | 6 | 4 | 0–8 | 2–7 | -77.6% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2718 | 2625 (0%) | 204629 (0%) | 41 | 284 | 6774 | 10.8 |
| hush | 100% | 1.00 | 0.2537 | 1690 (-36%) | 183233 (-10%) | 0 | 62 | 7253 | 10.0 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2575 | 1778 (0%) | 169260 (0%) | 38 | 217 | 13226 | 9.8 |
| hush | 100% | 1.00 | 0.2659 | 1261 (-29%) | 187744 (+11%) | 2 | 45 | 12100 | 10.8 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.6909 | 6515 (0%) | 701545 (0%) | 13 | 145 | 13687 | 26.3 |
| hush | 100% | 1.00 | 0.7020 | 5220 (-20%) | 744596 (+6%) | 2 | 47 | 12367 | 25.8 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.7814 | 10991 (0%) | 494473 (0%) | 11 | 717 | 23453 | 15.0 |
| hush | 100% | 1.00 | 0.4969 | 5503 (-50%) | 399161 (-19%) | 0 | 69 | 5868 | 14.8 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3793 | 4003 (0%) | 186333 (0%) | 11 | 673 | 22572 | 7.8 |
| hush | 100% | 0.92 | 0.3058 | 1856 (-54%) | 187694 (+1%) | 3 | 110 | 16100 | 8.3 |

## release-digest

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.7014 | 5682 (0%) | 356270 (0%) | 33 | 528 | 62415 | 9.8 |
| hush | 100% | 1.00 | 0.5332 | 4017 (-29%) | 292047 (-18%) | 8 | 99 | 38077 | 11.8 |

## rename-scope

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4236 | 5443 (0%) | 247725 (0%) | 24 | 666 | 16502 | 19.5 |
| hush | 100% | 1.00 | 0.3463 | 3246 (-40%) | 209101 (-16%) | 3 | 117 | 14327 | 16.8 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.5065 | 5918 (0%) | 287963 (0%) | 40 | 197 | 22989 | 24.8 |
| hush | 100% | 1.00 | 0.6090 | 7084 (+20%) | 291173 (+1%) | 6 | 62 | 30712 | 36.0 |
