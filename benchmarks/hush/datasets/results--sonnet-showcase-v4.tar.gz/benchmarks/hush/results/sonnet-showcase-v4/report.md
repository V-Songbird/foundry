# hush benchmark — run `sonnet-showcase-v4`

18 runs · model `sonnet` · generated from `results/sonnet-showcase-v4/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.2223 | 1644 | 198917 | 83 | 187 | 7.2 | 29 |
| **caveman** | 100% | 0.2175 | 1250 | 193111 | 40 | 95 | 7.0 | 26 |
| **hush** | 100% | 0.1779 | 1371 | 176697 | 20 | 113 | 6.7 | 28 |

Deltas vs baseline — cost: caveman -2%, hush -20%; output tokens: caveman -24%, hush -17%; context traffic: caveman -3%, hush -11%.

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2161 | 2304 (0%) | 234998 (0%) | 219 | 180 | 14650 | 10.0 |
| caveman | 100% | 1.00 | 0.2079 | 1983 (-14%) | 235111 (+0%) | 150 | 63 | 6977 | 11.0 |
| hush | 100% | 1.00 | 0.1778 | 1728 (-25%) | 198443 (-16%) | 93 | 78 | 6711 | 9.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2360 | 2067 (0%) | 309186 (0%) | 64 | 117 | 16258 | 11.0 |
| caveman | 100% | 1.00 | 0.2275 | 1965 (-5%) | 307084 (-1%) | 39 | 49 | 7669 | 11.0 |
| hush | 100% | 1.00 | 0.1900 | 1644 (-20%) | 232127 (-25%) | 9 | 87 | 7953 | 10.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0812 | 719 (0%) | 56815 (0%) | 0 | 233 | 14 | 2.0 |
| caveman | 100% | 0.67 | 0.0582 | 305 (-58%) | 30755 (-46%) | 0 | 132 | 0 | 1.0 |
| hush | 100% | 0.67 | 0.0663 | 554 (-23%) | 30292 (-47%) | 0 | 177 | 0 | 1.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3224 | 1843 (0%) | 257442 (0%) | 120 | 163 | 51683 | 10.0 |
| caveman | 100% | 1.00 | 0.2451 | 1473 (-20%) | 228620 (-11%) | 32 | 82 | 26963 | 9.0 |
| hush | 100% | 1.00 | 0.1479 | 1144 (-38%) | 159960 (-38%) | 0 | 50 | 4894 | 8.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3013 | 1713 (0%) | 138979 (0%) | 0 | 346 | 60389 | 3.0 |
| caveman | 100% | 1.00 | 0.3101 | 827 (-52%) | 146280 (+5%) | 0 | 196 | 60389 | 3.0 |
| hush | 100% | 1.00 | 0.3282 | 2289 (+34%) | 244721 (+76%) | 0 | 228 | 50529 | 5.0 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1769 | 1215 (0%) | 196081 (0%) | 96 | 81 | 13984 | 7.0 |
| caveman | 100% | 1.00 | 0.2564 | 944 (-22%) | 210815 (+8%) | 21 | 48 | 33957 | 7.0 |
| hush | 100% | 1.00 | 0.1571 | 865 (-29%) | 194641 (-1%) | 20 | 57 | 6118 | 7.0 |
