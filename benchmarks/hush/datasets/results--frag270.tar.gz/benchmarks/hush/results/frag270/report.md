# hush benchmark — run `frag270`

24 runs · model `opus` · generated from `results/frag270/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.6601 | 8798 | 364982 | 47 | 594 | 19.5 | 122 |
| **fragment** | 100% | 0.4509 | 3626 | 330986 | 4 | 49 | 11.5 | 62 |
| **hush** | 100% | 0.6414 | 6528 | 412195 | 6 | 54 | 21.0 | 101 |

Deltas vs baseline — cost: fragment -32%, hush -3%; output tokens: fragment -59%, hush -26%; context traffic: fragment -9%, hush +13%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 1.1245 | 1.1245 | 1.0940–1.1550 | 1.0050–1.2440 | — | — | — | 100% |
| long-session | fragment | 2 | 0.7436 | 0.7436 | 0.7385–0.7488 | 0.7234–0.7639 | -33.9% | 100% | — | 100% |
| long-session | hush | 2 | 1.0432 | 1.0432 | 0.9437–1.1426 | 0.6531–1.4332 | -7.2% | 100% | — | 100% |
| noisy-output | baseline | 4 | 0.3542 | 0.3813 | 0.2904–0.4451 | 0.2613–0.5013 | — | — | — | 100% |
| noisy-output | fragment | 4 | 0.3241 | 0.3329 | 0.3194–0.3377 | 0.3083–0.3575 | -8.5% | 50% | failing-suite +12.2% | 100% |
| noisy-output | hush | 4 | 0.3045 | 0.3190 | 0.2985–0.3249 | 0.2843–0.3537 | -14.0% | 50% | failing-suite +4.2% | 100% |
| search-heavy | baseline | 2 | 0.7534 | 0.7534 | 0.6260–0.8807 | 0.2543–1.2524 | — | — | — | 100% |
| search-heavy | fragment | 2 | 0.3939 | 0.3939 | 0.3826–0.4053 | 0.3495–0.4384 | -47.7% | 100% | — | 100% |
| search-heavy | hush | 2 | 0.8843 | 0.8843 | 0.7536–1.0150 | 0.3719–1.3967 | +17.4% | 0% | repo-sweep +17.4% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 686177 | 686177 | 674107–698248 | 638861–733493 | — | — | — | 100% |
| long-session | fragment | 2 | 626549 | 626549 | 566920–686179 | 392801–860297 | -8.7% | 100% | — | 100% |
| long-session | hush | 2 | 817455 | 817455 | 717312–917597 | 424895–1210014 | +19.1% | 0% | incident-forensics +19.1% | 100% |
| noisy-output | baseline | 4 | 199001 | 191746 | 186890–203857 | 170492–212999 | — | — | — | 100% |
| noisy-output | fragment | 4 | 221697 | 220643 | 209047–233292 | 190739–250546 | +11.4% | 0% | failing-suite +19.2% | 100% |
| noisy-output | hush | 4 | 189328 | 193119 | 186242–196205 | 177077–209161 | -4.9% | 50% | log-triage +8.7% | 100% |
| search-heavy | baseline | 2 | 390258 | 390258 | 341663–438854 | 199764–580752 | — | — | — | 100% |
| search-heavy | fragment | 2 | 256112 | 256112 | 244412–267811 | 210250–301973 | -34.4% | 100% | — | 100% |
| search-heavy | hush | 2 | 445086 | 445086 | 443551–446621 | 439069–451103 | +14.0% | 0% | repo-sweep +14.0% | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 38121 | 38121 | 37450–38792 | 35492–40750 | — | — | — | 100% |
| long-session | fragment | 2 | 35068 | 35068 | 34484–35651 | 32780–37356 | -8.0% | 100% | — | 100% |
| long-session | hush | 2 | 36716 | 36716 | 35501–37930 | 31956–41475 | -3.7% | 100% | — | 100% |
| noisy-output | baseline | 4 | 27335 | 27414 | 26550–28199 | 26184–28644 | — | — | — | 100% |
| noisy-output | fragment | 4 | 31612 | 31460 | 30950–32122 | 30624–32296 | +15.6% | 0% | failing-suite +18.9% | 100% |
| noisy-output | hush | 4 | 31205 | 30899 | 30567–31538 | 29995–31803 | +14.2% | 0% | failing-suite +16.7% | 100% |
| search-heavy | baseline | 2 | 36592 | 36592 | 34577–38606 | 28695–44488 | — | — | — | 100% |
| search-heavy | fragment | 2 | 34092 | 34092 | 33668–34515 | 32432–35752 | -6.8% | 100% | — | 100% |
| search-heavy | hush | 2 | 40774 | 40774 | 39060–42488 | 34056–47492 | +11.4% | 0% | repo-sweep +11.4% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 17078 | 17078 | 16679–17478 | 15512–18644 | — | — | — | 100% |
| long-session | fragment | 2 | 7351 | 7351 | 6688–8013 | 4753–9948 | -57.0% | 100% | — | 100% |
| long-session | hush | 2 | 12766 | 12766 | 12008–13523 | 9797–15734 | -25.3% | 100% | — | 100% |
| noisy-output | baseline | 4 | 3697 | 3959 | 2535–5121 | 2261–5656 | — | — | — | 100% |
| noisy-output | fragment | 4 | 1877 | 2115 | 1214–2778 | 1020–3209 | -49.2% | 100% | — | 100% |
| noisy-output | hush | 4 | 2039 | 2266 | 1415–2890 | 1204–3328 | -44.8% | 100% | — | 100% |
| search-heavy | baseline | 2 | 10198 | 10198 | 7884–12512 | 1127–19269 | — | — | — | 100% |
| search-heavy | fragment | 2 | 2924 | 2924 | 2869–2978 | 2709–3138 | -71.3% | 100% | — | 100% |
| search-heavy | hush | 2 | 8816 | 8816 | 6750–10881 | 718–16913 | -13.6% | 100% | — | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 2 | 14 | 14 | 10–18 | -2–30 | — | — | — | 100% |
| long-session | fragment | 2 | 0 | 0 | 0–0 | 0–0 | -100.0% | 100% | — | 100% |
| long-session | hush | 2 | 0 | 0 | 0–0 | 0–0 | -100.0% | 100% | — | 100% |
| noisy-output | baseline | 4 | 49 | 51 | 15–85 | 6–96 | — | — | — | 100% |
| noisy-output | fragment | 4 | 6 | 5 | 5–7 | 2–8 | -87.6% | 100% | — | 100% |
| noisy-output | hush | 4 | 7 | 7 | 6–7 | 6–7 | -86.6% | 100% | — | 100% |
| search-heavy | baseline | 2 | 73 | 73 | 68–77 | 54–91 | — | — | — | 100% |
| search-heavy | fragment | 2 | 6 | 6 | 6–6 | 6–6 | -91.7% | 100% | — | 100% |
| search-heavy | hush | 2 | 11 | 11 | 10–12 | 7–15 | -84.8% | 100% | — | 100% |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2856 | 2513 (0%) | 202282 (0%) | 90 | 333 | 10452 | 11.5 |
| fragment | 100% | 1.00 | 0.3204 | 1210 (-52%) | 241108 (+19%) | 4 | 44 | 12118 | 9.5 |
| hush | 100% | 1.00 | 0.2975 | 1396 (-44%) | 189328 (-6%) | 7 | 47 | 11783 | 10.0 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 1.1245 | 17078 (0%) | 686177 (0%) | 14 | 1021 | 32294 | 18.5 |
| fragment | 100% | 1.00 | 0.7436 | 7351 (-57%) | 626549 (-9%) | 0 | 52 | 13273 | 18.5 |
| hush | 100% | 1.00 | 1.0432 | 12766 (-25%) | 817455 (+19%) | 0 | 52 | 17091 | 23.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4770 | 5404 (0%) | 181210 (0%) | 12 | 743 | 17060 | 8.5 |
| fragment | 100% | 0.67 | 0.3454 | 3019 (-44%) | 200178 (+10%) | 6 | 56 | 10521 | 6.5 |
| hush | 100% | 0.67 | 0.3404 | 3137 (-42%) | 196910 (+9%) | 6 | 64 | 9644 | 7.0 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.7534 | 10198 (0%) | 390258 (0%) | 73 | 282 | 33853 | 39.5 |
| fragment | 100% | 1.00 | 0.3939 | 2924 (-71%) | 256112 (-34%) | 6 | 45 | 13842 | 11.5 |
| hush | 100% | 1.00 | 0.8843 | 8816 (-14%) | 445086 (+14%) | 11 | 55 | 32192 | 44.0 |
