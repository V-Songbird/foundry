# hush benchmark — run `sonnet-showcase-final`

90 runs · model `sonnet` · generated from `results/sonnet-showcase-final/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.2197 | 1769 | 193709 | 91 | 185 | 7.2 | 32 |
| **caveman** | 100% | 0.2091 | 1194 | 187732 | 34 | 92 | 6.9 | 29 |
| **hush** | 100% | 0.1881 | 1375 | 198929 | 29 | 102 | 7.5 | 35 |

Deltas vs baseline — cost: caveman -5%, hush -14%; output tokens: caveman -33%, hush -22%; context traffic: caveman -3%, hush +3%.

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2119 | 2757 (0%) | 213685 (0%) | 241 | 139 | 12547 | 9.4 |
| caveman | 100% | 1.00 | 0.1965 | 1732 (-37%) | 221928 (+4%) | 104 | 66 | 7288 | 9.4 |
| hush | 100% | 1.00 | 0.1941 | 1720 (-38%) | 226823 (+6%) | 99 | 56 | 8389 | 10.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2098 | 2002 (0%) | 245733 (0%) | 81 | 115 | 14369 | 10.2 |
| caveman | 100% | 1.00 | 0.2203 | 1848 (-8%) | 270040 (+10%) | 23 | 65 | 10024 | 10.4 |
| hush | 100% | 1.00 | 0.1881 | 1678 (-16%) | 231467 (-6%) | 13 | 79 | 7285 | 9.6 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.87 | 0.0611 | 634 (0%) | 34029 (0%) | 0 | 243 | 3 | 1.2 |
| caveman | 100% | 0.93 | 0.0576 | 270 (-57%) | 30753 (-10%) | 0 | 102 | 0 | 1.0 |
| hush | 100% | 1.00 | 0.0860 | 595 (-6%) | 60803 (+79%) | 0 | 171 | 14 | 2.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3225 | 1991 (0%) | 285038 (0%) | 129 | 157 | 47819 | 10.8 |
| caveman | 100% | 1.00 | 0.2465 | 1532 (-23%) | 240426 (-16%) | 52 | 61 | 24683 | 9.8 |
| hush | 100% | 1.00 | 0.2142 | 1559 (-22%) | 268434 (-6%) | 32 | 78 | 13421 | 10.8 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3141 | 1802 (0%) | 174076 (0%) | 9 | 367 | 60429 | 4.0 |
| caveman | 100% | 1.00 | 0.3131 | 826 (-54%) | 152470 (-12%) | 3 | 211 | 60390 | 3.2 |
| hush | 100% | 1.00 | 0.2767 | 1651 (-8%) | 185415 (+7%) | 10 | 177 | 43485 | 4.6 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1987 | 1428 (0%) | 209691 (0%) | 88 | 86 | 18285 | 7.8 |
| caveman | 100% | 1.00 | 0.2208 | 956 (-33%) | 210775 (+1%) | 18 | 49 | 22177 | 7.4 |
| hush | 100% | 1.00 | 0.1693 | 1045 (-27%) | 220634 (+5%) | 19 | 50 | 6323 | 7.8 |
