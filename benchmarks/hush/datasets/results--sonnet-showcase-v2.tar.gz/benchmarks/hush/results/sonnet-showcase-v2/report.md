# hush benchmark — run `sonnet-showcase-v2`

18 runs · model `sonnet` · generated from `results/sonnet-showcase-v2/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.2460 | 1837 | 219154 | 71 | 191 | 7.8 | 31 |
| **caveman** | 100% | 0.2347 | 1287 | 190408 | 34 | 104 | 7.3 | 27 |
| **hush** | 100% | 0.2094 | 1439 | 192494 | 25 | 117 | 6.8 | 28 |

Deltas vs baseline — cost: caveman -5%, hush -15%; output tokens: caveman -30%, hush -22%; context traffic: caveman -13%, hush -12%.

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1928 | 2616 (0%) | 194091 (0%) | 203 | 143 | 9550 | 9.0 |
| caveman | 100% | 1.00 | 0.1993 | 1893 (-28%) | 232516 (+20%) | 97 | 71 | 5732 | 11.0 |
| hush | 100% | 1.00 | 0.1766 | 1675 (-36%) | 198299 (+2%) | 100 | 91 | 6713 | 9.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2175 | 2195 (0%) | 316157 (0%) | 72 | 108 | 8815 | 12.0 |
| caveman | 100% | 1.00 | 0.2313 | 1747 (-20%) | 250094 (-21%) | 34 | 91 | 16109 | 10.0 |
| hush | 100% | 1.00 | 0.2249 | 1916 (-13%) | 330823 (+5%) | 9 | 75 | 8053 | 10.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0937 | 920 (0%) | 85503 (0%) | 0 | 295 | 51 | 3.0 |
| caveman | 100% | 1.00 | 0.0582 | 309 (-66%) | 30755 (-64%) | 0 | 113 | 0 | 1.0 |
| hush | 100% | 0.67 | 0.0909 | 519 (-44%) | 60720 (-29%) | 0 | 163 | 14 | 2.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3467 | 1849 (0%) | 316976 (0%) | 103 | 116 | 53804 | 11.0 |
| caveman | 100% | 1.00 | 0.3475 | 1776 (-4%) | 271482 (-14%) | 52 | 95 | 52253 | 11.0 |
| hush | 100% | 1.00 | 0.1658 | 1454 (-21%) | 192566 (-39%) | 30 | 50 | 5404 | 9.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3033 | 1830 (0%) | 139014 (0%) | 0 | 336 | 60389 | 3.0 |
| caveman | 100% | 1.00 | 0.3092 | 778 (-57%) | 146242 (+5%) | 0 | 192 | 60389 | 3.0 |
| hush | 100% | 1.00 | 0.2892 | 2230 (+22%) | 161562 (+16%) | 0 | 263 | 48451 | 4.0 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3222 | 1614 (0%) | 263182 (0%) | 47 | 149 | 14467 | 9.0 |
| caveman | 100% | 1.00 | 0.2626 | 1219 (-24%) | 211361 (-20%) | 21 | 62 | 34094 | 8.0 |
| hush | 100% | 1.00 | 0.3092 | 838 (-48%) | 210992 (-20%) | 11 | 57 | 16214 | 7.0 |
