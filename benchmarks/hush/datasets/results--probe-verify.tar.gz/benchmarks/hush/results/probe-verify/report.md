# hush benchmark — run `probe-verify`

45 runs · model `sonnet` · generated from `results/probe-verify/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.1932 | 1585 | 194821 | 39 | 147 | 6.9 | 26 |
| **brief** | 100% | 0.1804 | 1131 | 172875 | 23 | 86 | 6.5 | 22 |
| **efficiency** | 100% | 0.1677 | 1007 | 178997 | 11 | 77 | 6.7 | 20 |

Deltas vs baseline — cost: brief -7%, efficiency -13%; output tokens: brief -29%, efficiency -36%; context traffic: brief -11%, efficiency -8%.

## bugfix-expiry

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2250 | 691 (0%) | 144936 (0%) | 35 | 28 | 2113 | 6.0 |
| brief | 100% | 1.00 | 0.1182 | 650 (-6%) | 152549 (+5%) | 7 | 23 | 2109 | 6.0 |
| efficiency | 100% | 1.00 | 0.1257 | 607 (-12%) | 159469 (+10%) | 18 | 17 | 1394 | 6.0 |

## bugfix-pagination

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1073 | 623 (0%) | 144883 (0%) | 18 | 34 | 2190 | 6.0 |
| brief | 100% | 1.00 | 0.1172 | 589 (-5%) | 152508 (+5%) | 19 | 22 | 2187 | 6.0 |
| efficiency | 100% | 1.00 | 0.1280 | 604 (-3%) | 159852 (+10%) | 7 | 29 | 2192 | 6.0 |

## checkout-bug

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1244 | 1119 (0%) | 149016 (0%) | 38 | 60 | 4426 | 8.0 |
| brief | 100% | 1.00 | 0.1418 | 1284 (+15%) | 158660 (+6%) | 37 | 26 | 5014 | 8.0 |
| efficiency | 100% | 1.00 | 0.1423 | 962 (-14%) | 163647 (+10%) | 17 | 22 | 4430 | 8.0 |

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2146 | 3518 (0%) | 228774 (0%) | 259 | 134 | 9933 | 10.0 |
| brief | 100% | 1.00 | 0.1700 | 1926 (-45%) | 195418 (-15%) | 138 | 56 | 6775 | 9.0 |
| efficiency | 100% | 1.00 | 0.1775 | 1477 (-58%) | 233782 (+2%) | 59 | 86 | 5354 | 10.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3855 | 2501 (0%) | 372293 (0%) | 37 | 146 | 59797 | 12.0 |
| brief | 100% | 1.00 | 0.1773 | 1622 (-35%) | 228267 (-39%) | 12 | 71 | 7887 | 10.0 |
| efficiency | 100% | 1.00 | 0.1875 | 1491 (-40%) | 238812 (-36%) | 9 | 75 | 8324 | 10.0 |

## explain-rebase

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0609 | 506 (0%) | 28178 (0%) | 0 | 234 | 0 | 1.0 |
| brief | 100% | 1.00 | 0.0660 | 272 (-46%) | 29713 (+5%) | 0 | 113 | 0 | 1.0 |
| efficiency | 100% | 1.00 | 0.0762 | 368 (-27%) | 31175 (+11%) | 0 | 103 | 0 | 1.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0625 | 613 (0%) | 28177 (0%) | 0 | 248 | 0 | 1.0 |
| brief | 100% | 1.00 | 0.0676 | 385 (-37%) | 29712 (+5%) | 0 | 133 | 0 | 1.0 |
| efficiency | 100% | 0.67 | 0.0725 | 125 (-80%) | 31174 (+11%) | 0 | 49 | 0 | 1.0 |

## incident-followup

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4511 | 3666 (0%) | 511556 (0%) | 0 | 304 | 60791 | 9.0 |
| brief | 100% | 1.00 | 0.4166 | 2274 (-38%) | 457291 (-11%) | 0 | 228 | 60943 | 8.0 |
| efficiency | 100% | 1.00 | 0.4209 | 1897 (-48%) | 468233 (-8%) | 0 | 150 | 60540 | 8.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2049 | 2177 (0%) | 287933 (0%) | 81 | 136 | 10969 | 12.0 |
| brief | 100% | 1.00 | 0.3417 | 1553 (-29%) | 324810 (+13%) | 63 | 48 | 52891 | 11.0 |
| efficiency | 100% | 1.00 | 0.1763 | 1380 (-37%) | 233375 (-19%) | 23 | 59 | 6297 | 10.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2951 | 1807 (0%) | 138575 (0%) | 0 | 341 | 60097 | 3.0 |
| brief | 100% | 1.00 | 0.2931 | 1022 (-43%) | 143213 (+3%) | 7 | 160 | 60177 | 3.0 |
| efficiency | 100% | 1.00 | 0.2979 | 744 (-59%) | 147466 (+6%) | 0 | 207 | 60097 | 3.0 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1806 | 1229 (0%) | 231487 (0%) | 43 | 64 | 14096 | 8.0 |
| brief | 100% | 1.00 | 0.2331 | 884 (-28%) | 203876 (-12%) | 26 | 53 | 33958 | 7.0 |
| efficiency | 100% | 1.00 | 0.1468 | 728 (-41%) | 196794 (-15%) | 7 | 26 | 4192 | 7.0 |

## refactor-rename

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2234 | 2448 (0%) | 370768 (0%) | 70 | 21 | 5570 | 15.0 |
| brief | 100% | 1.00 | 0.2048 | 2243 (-8%) | 291286 (-21%) | 30 | 18 | 5728 | 16.0 |
| efficiency | 100% | 1.00 | 0.2043 | 2236 (-9%) | 267516 (-28%) | 22 | 24 | 5275 | 15.0 |

## repo-summary

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1056 | 1370 (0%) | 87132 (0%) | 6 | 274 | 4107 | 7.0 |
| brief | 100% | 1.00 | 0.1284 | 1490 (+9%) | 122399 (+40%) | 6 | 184 | 4504 | 8.0 |
| efficiency | 100% | 1.00 | 0.1369 | 1382 (+1%) | 128257 (+47%) | 7 | 229 | 4534 | 8.0 |

## sidecar-follow

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1823 | 809 (0%) | 141727 (0%) | 0 | 80 | 24931 | 4.0 |
| brief | 100% | 1.00 | 0.1615 | 351 (-57%) | 73726 (-48%) | 0 | 47 | 24908 | 2.0 |
| efficiency | 100% | 1.00 | 0.1492 | 916 (+13%) | 194243 (+37%) | 0 | 49 | 3397 | 6.0 |

## write-validator

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0754 | 701 (0%) | 56875 (0%) | 0 | 99 | 175 | 2.0 |
| brief | 100% | 1.00 | 0.0681 | 424 (-40%) | 29699 (-48%) | 0 | 107 | 0 | 1.0 |
| efficiency | 100% | 1.00 | 0.0735 | 195 (-72%) | 31161 (-45%) | 0 | 30 | 0 | 1.0 |
