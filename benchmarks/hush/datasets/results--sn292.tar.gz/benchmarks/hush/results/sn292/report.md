# hush benchmark — run `sn292`

32 runs · model `sonnet` · generated from `results/sn292/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Rubric coverage | Cost USD | Output tok | Context traffic tok | Narration words | Silent | One message | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 96% | 0.2577 | 4656 | 433841 | 52 | 31% | 19% | 168 | 15.9 | 58 |
| **hush** | 100% | 98% | 0.2350 | 4070 | 371460 | 8 | 56% | 44% | 89 | 16.3 | 56 |

Deltas vs baseline — cost: hush -9%; output tokens: hush -13%; context traffic: hush -14%.

## Distributions by segment

### Cost USD

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 0.2564 | 0.3048 | 0.2333–0.3280 | 0.1601–0.4495 | — | — | — | 100% |
| long-session | hush | 4 | 0.3193 | 0.3201 | 0.3183–0.3211 | 0.3169–0.3234 | +24.5% | 50% | feature-drift +24.0% | 100% |
| noisy-output | baseline | 8 | 0.1816 | 0.2403 | 0.1276–0.3157 | 0.1391–0.3415 | — | — | — | 100% |
| noisy-output | hush | 8 | 0.2057 | 0.1978 | 0.1341–0.2200 | 0.1469–0.2487 | +13.3% | 50% | dep-bump-warnings +16.3% | 100% |
| search-heavy | baseline | 4 | 0.2469 | 0.2452 | 0.1109–0.3813 | 0.0897–0.4007 | — | — | — | 100% |
| search-heavy | hush | 4 | 0.2179 | 0.2244 | 0.1392–0.3032 | 0.1164–0.3325 | -11.7% | 50% | rename-scope +22.1% | 100% |

### Context traffic tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 727718 | 770185 | 617561–880342 | 409505–1130865 | — | — | — | 100% |
| long-session | hush | 4 | 760014 | 760959 | 653163–867809 | 638095–883822 | +4.4% | 50% | feature-drift +19.5% | 100% |
| noisy-output | baseline | 8 | 229693 | 326971 | 203666–386124 | 184497–469445 | — | — | — | 100% |
| noisy-output | hush | 8 | 248366 | 235124 | 194031–278968 | 193751–276497 | +8.1% | 75% | failing-suite +14.2% | 100% |
| search-heavy | baseline | 4 | 318899 | 311235 | 155759–474375 | 124670–497800 | — | — | — | 100% |
| search-heavy | hush | 4 | 247914 | 254634 | 170986–331562 | 158738–350530 | -22.3% | 50% | rename-scope +16.1% | 100% |

### Context per API call tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 36294 | 43472 | 35702–44063 | 28582–58363 | — | — | — | 100% |
| long-session | hush | 4 | 40180 | 40149 | 39600–40729 | 39426–40873 | +10.7% | 50% | feature-drift +11.4% | 100% |
| noisy-output | baseline | 8 | 37328 | 43125 | 33819–50448 | 34485–51765 | — | — | — | 100% |
| noisy-output | hush | 8 | 35145 | 37655 | 34310–37489 | 33464–41846 | -5.8% | 50% | failing-suite +6.7% | 100% |
| search-heavy | baseline | 4 | 38197 | 38993 | 32765–44425 | 31589–46397 | — | — | — | 100% |
| search-heavy | hush | 4 | 37419 | 38223 | 34197–41445 | 33339–43107 | -2.0% | 50% | rename-scope +4.6% | 100% |

### Output tok

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 3764 | 4070 | 3682–4152 | 3343–4796 | — | — | — | 100% |
| long-session | hush | 4 | 4162 | 4154 | 3464–4852 | 3210–5098 | +10.6% | 50% | feature-drift +31.7% | 100% |
| noisy-output | baseline | 8 | 1873 | 4068 | 1419–3971 | 855–7282 | — | — | — | 100% |
| noisy-output | hush | 8 | 1400 | 2646 | 1149–2894 | 808–4483 | -25.3% | 75% | failing-suite +3.5% | 100% |
| search-heavy | baseline | 4 | 6290 | 6417 | 2018–10689 | 1394–11440 | — | — | — | 100% |
| search-heavy | hush | 4 | 7205 | 6833 | 3899–10139 | 2575–11091 | +14.5% | 50% | rename-scope +62.3% | 100% |

### Narration words

| Segment | Arm | n | median | mean | p25–p75 | 95% CI | vs baseline (median) | win rate | worst task | pass |
|---|---|---|---|---|---|---|---|---|---|---|
| long-session | baseline | 4 | 4 | 6 | 0–10 | -2–14 | — | — | — | 100% |
| long-session | hush | 4 | 3 | 8 | 0–10 | -4–19 | -37.5% | 0% | feature-drift +20.0% | 100% |
| noisy-output | baseline | 8 | 77 | 73 | 50–97 | 36–110 | — | — | — | 100% |
| noisy-output | hush | 8 | 0 | 5 | 0–12 | 0–10 | -100.0% | 100% | — | 100% |
| search-heavy | baseline | 4 | 67 | 56 | 47–75 | 18–94 | — | — | — | 100% |
| search-heavy | hush | 4 | 14 | 14 | 0–27 | -2–29 | -79.7% | 100% | — | 100% |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1428 | 2036 (0%) | 258459 (0%) | 103 | 108 | 15887 | 10.5 |
| hush | 100% | 1.00 | 0.1661 | 1685 (-17%) | 245972 (-5%) | 6 | 77 | 27251 | 10.0 |

## failing-suite

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1166 | 1219 (0%) | 229693 (0%) | 69 | 38 | 11382 | 10.5 |
| hush | 100% | 1.00 | 0.1332 | 1262 (+4%) | 262293 (+14%) | 14 | 37 | 12186 | 11.0 |

## feature-drift

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2564 | 3764 (0%) | 727718 (0%) | 13 | 27 | 13366 | 23.5 |
| hush | 100% | 1.00 | 0.3179 | 4959 (+32%) | 869502 (+19%) | 15 | 34 | 15882 | 26.0 |

## incident-forensics

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3532 | 4375 (0%) | 812653 (0%) | 0 | 260 | 47134 | 15.5 |
| hush | 100% | 1.00 | 0.3223 | 3350 (-23%) | 652416 (-20%) | 0 | 149 | 49730 | 16.5 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2434 | 1619 (0%) | 170443 (0%) | 0 | 354 | 60139 | 4.0 |
| hush | 100% | 1.00 | 0.2057 | 791 (-51%) | 154351 (-9%) | 0 | 120 | 23514 | 4.5 |

## release-digest

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 0.67 | 0.4584 | 11400 (0%) | 649290 (0%) | 121 | 186 | 74743 | 13.5 |
| hush | 100% | 0.83 | 0.2861 | 6846 (-40%) | 277881 (-57%) | 0 | 106 | 51932 | 9.0 |

## rename-scope

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1078 | 1984 (0%) | 146859 (0%) | 35 | 329 | 13322 | 9.5 |
| hush | 100% | 1.00 | 0.1316 | 3221 (+62%) | 170508 (+16%) | 0 | 141 | 9853 | 13.5 |

## repo-sweep

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3826 | 10850 (0%) | 475612 (0%) | 77 | 43 | 53378 | 40.5 |
| hush | 100% | 1.00 | 0.3172 | 10446 (-4%) | 338761 (-29%) | 27 | 48 | 32406 | 40.0 |
