# hush benchmark — run `pub0721`

120 runs · model `sonnet` · generated from `results/pub0721/runs/`

## Overall (mean per run)

| Arm | Ground truth pass | Cost USD | Output tok | Context traffic tok | Narration words | Final words | Turns | Wall s |
|---|---|---|---|---|---|---|---|---|
| **baseline** | 100% | 0.1867 | 1532 | 181571 | 45 | 157 | 6.8 | 26 |
| **brief** | 100% | 0.1718 | 1155 | 168637 | 21 | 101 | 6.5 | 22 |
| **efficiency** | 97% | 0.1713 | 1085 | 183652 | 15 | 74 | 6.8 | 23 |
| **hush** | 100% | 0.0995 | 1292 | 178062 | 2 | 84 | 7.1 | 27 |

Deltas vs baseline — cost: brief -8%, efficiency -8%, hush -47%; output tokens: brief -25%, efficiency -29%, hush -16%; context traffic: brief -7%, efficiency +1%, hush -2%.

## bugfix-expiry

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.2254 | 709 (0%) | 144984 (0%) | 46 | 32 | 2109 | 6.0 |
| brief | 100% | 1.00 | 0.1178 | 632 (-11%) | 152569 (+5%) | 22 | 23 | 2113 | 6.0 |
| efficiency | 100% | 1.00 | 0.1466 | 708 (-0%) | 209178 (+44%) | 6 | 18 | 2733 | 7.5 |
| hush | 100% | 1.00 | 0.0795 | 757 (+7%) | 178721 (+23%) | 17 | 40 | 2253 | 6.5 |

## bugfix-pagination

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1079 | 636 (0%) | 145109 (0%) | 19 | 36 | 2246 | 6.0 |
| brief | 100% | 1.00 | 0.1193 | 663 (+4%) | 153106 (+6%) | 18 | 24 | 2306 | 6.0 |
| efficiency | 100% | 1.00 | 0.1345 | 663 (+4%) | 176314 (+22%) | 14 | 27 | 2285 | 6.5 |
| hush | 100% | 1.00 | 0.0727 | 660 (+4%) | 162524 (+12%) | 10 | 30 | 2306 | 6.0 |

## checkout-bug

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1362 | 1430 (0%) | 165738 (0%) | 46 | 53 | 4321 | 8.5 |
| brief | 100% | 1.00 | 0.1389 | 1247 (-13%) | 157678 (-5%) | 23 | 24 | 4690 | 8.0 |
| efficiency | 100% | 1.00 | 0.1794 | 1437 (+1%) | 248619 (+50%) | 27 | 33 | 5034 | 10.0 |
| hush | 100% | 1.00 | 0.1007 | 1483 (+4%) | 169235 (+2%) | 0 | 50 | 5269 | 9.0 |

## coupon-currency-flaky

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1718 | 2440 (0%) | 188048 (0%) | 239 | 127 | 7220 | 9.0 |
| brief | 100% | 1.00 | 0.1703 | 1699 (-30%) | 210540 (+12%) | 87 | 64 | 6634 | 10.5 |
| efficiency | 100% | 1.00 | 0.1941 | 1885 (-23%) | 251812 (+34%) | 104 | 66 | 6183 | 10.5 |
| hush | 100% | 1.00 | 0.1419 | 1683 (-31%) | 260274 (+38%) | 0 | 94 | 7903 | 11.0 |

## dep-bump-warnings

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1951 | 1949 (0%) | 258982 (0%) | 72 | 130 | 11346 | 10.0 |
| brief | 100% | 1.00 | 0.2146 | 1751 (-10%) | 261554 (+1%) | 26 | 83 | 15945 | 10.0 |
| efficiency | 100% | 1.00 | 0.1717 | 1414 (-27%) | 217647 (-16%) | 11 | 58 | 5935 | 9.0 |
| hush | 100% | 1.00 | 0.1558 | 1876 (-4%) | 295797 (+14%) | 0 | 98 | 7977 | 11.0 |

## explain-rebase

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0618 | 567 (0%) | 28176 (0%) | 0 | 275 | 0 | 1.0 |
| brief | 100% | 1.00 | 0.0679 | 403 (-29%) | 29711 (+5%) | 0 | 163 | 0 | 1.0 |
| efficiency | 100% | 1.00 | 0.0753 | 315 (-44%) | 31173 (+11%) | 0 | 128 | 0 | 1.0 |
| hush | 100% | 0.83 | 0.0155 | 364 (-36%) | 31360 (+11%) | 0 | 151 | 0 | 1.0 |

## explain-rerender

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0637 | 695 (0%) | 28175 (0%) | 0 | 242 | 0 | 1.0 |
| brief | 100% | 1.00 | 0.0687 | 459 (-34%) | 29710 (+5%) | 0 | 126 | 0 | 1.0 |
| efficiency | 100% | 1.00 | 0.0738 | 214 (-69%) | 31172 (+11%) | 0 | 87 | 0 | 1.0 |
| hush | 100% | 1.00 | 0.0232 | 504 (-27%) | 47184 (+67%) | 0 | 113 | 7 | 1.5 |

## incident-followup

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.4429 | 3701 (0%) | 479440 (0%) | 0 | 293 | 60809 | 9.0 |
| brief | 100% | 1.00 | 0.4014 | 2579 (-30%) | 394469 (-18%) | 4 | 378 | 60715 | 7.0 |
| efficiency | 50% | 0.83 | 0.4400 | 2242 (-39%) | 502186 (+5%) | 10 | 99 | 60639 | 8.5 |
| hush | 100% | 1.00 | 0.2390 | 3272 (-12%) | 336296 (-30%) | 0 | 83 | 9224 | 9.0 |

## incident-pool-leak

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3472 | 2306 (0%) | 317131 (0%) | 141 | 131 | 53408 | 11.5 |
| brief | 100% | 1.00 | 0.1960 | 1868 (-19%) | 277582 (-12%) | 67 | 60 | 8088 | 11.5 |
| efficiency | 100% | 1.00 | 0.1692 | 1287 (-44%) | 216571 (-32%) | 19 | 76 | 6387 | 9.5 |
| hush | 100% | 1.00 | 0.1469 | 1606 (-30%) | 264369 (-17%) | 0 | 101 | 10635 | 11.0 |

## log-triage

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.3153 | 1831 (0%) | 197648 (0%) | 0 | 371 | 60322 | 4.5 |
| brief | 100% | 1.00 | 0.2907 | 882 (-52%) | 143169 (-28%) | 0 | 209 | 60097 | 3.0 |
| efficiency | 100% | 1.00 | 0.3021 | 989 (-46%) | 147576 (-25%) | 0 | 195 | 60097 | 3.0 |
| hush | 100% | 1.00 | 0.0868 | 1155 (-37%) | 120946 (-39%) | 0 | 138 | 8929 | 3.5 |

## noisy-build

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1793 | 1215 (0%) | 228368 (0%) | 60 | 77 | 14148 | 7.5 |
| brief | 100% | 1.00 | 0.2337 | 908 (-25%) | 203962 (-11%) | 17 | 51 | 33802 | 7.0 |
| efficiency | 100% | 1.00 | 0.1413 | 739 (-39%) | 179802 (-21%) | 10 | 37 | 4034 | 6.5 |
| hush | 100% | 1.00 | 0.1132 | 1052 (-13%) | 236052 (+3%) | 0 | 73 | 6190 | 8.0 |

## refactor-rename

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1946 | 2381 (0%) | 276928 (0%) | 43 | 30 | 5627 | 15.5 |
| brief | 100% | 1.00 | 0.2068 | 2301 (-3%) | 290417 (+5%) | 44 | 24 | 5940 | 16.0 |
| efficiency | 100% | 1.00 | 0.1990 | 2157 (-9%) | 251520 (-9%) | 17 | 16 | 5607 | 14.5 |
| hush | 100% | 1.00 | 0.1516 | 2344 (-2%) | 259847 (-6%) | 0 | 39 | 5688 | 15.5 |

## repo-summary

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1265 | 2017 (0%) | 116310 (0%) | 14 | 347 | 4668 | 8.0 |
| brief | 100% | 1.00 | 0.1120 | 1163 (-42%) | 91747 (-21%) | 2 | 187 | 4107 | 7.0 |
| efficiency | 100% | 1.00 | 0.1347 | 1286 (-36%) | 128017 (+10%) | 9 | 196 | 4445 | 8.0 |
| hush | 100% | 1.00 | 0.0758 | 1570 (-22%) | 113508 (-2%) | 0 | 169 | 4283 | 7.5 |

## sidecar-follow

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.1717 | 573 (0%) | 120371 (0%) | 0 | 85 | 24962 | 3.5 |
| brief | 100% | 1.00 | 0.1716 | 401 (-30%) | 103642 (-14%) | 0 | 43 | 24928 | 3.0 |
| efficiency | 100% | 1.00 | 0.1334 | 735 (+28%) | 132032 (+10%) | 0 | 39 | 5397 | 5.0 |
| hush | 100% | 1.00 | 0.0770 | 825 (+44%) | 163475 (+36%) | 0 | 40 | 2976 | 5.0 |

## write-validator

| Arm | Pass | Score | Cost USD | Output tok | Traffic tok | Narration w | Final w | Tool-result chars | Turns |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 100% | 1.00 | 0.0610 | 527 (0%) | 28162 (0%) | 0 | 128 | 0 | 1.0 |
| brief | 100% | 1.00 | 0.0674 | 373 (-29%) | 29697 (+5%) | 0 | 67 | 0 | 1.0 |
| efficiency | 100% | 1.00 | 0.0737 | 213 (-60%) | 31159 (+11%) | 0 | 40 | 0 | 1.0 |
| hush | 100% | 1.00 | 0.0135 | 235 (-55%) | 31346 (+11%) | 0 | 49 | 0 | 1.0 |
