# foreman handoff benchmark — run `ex4a-opus2`

12 runs · model `opus` · generated from `results/ex4a-opus2/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **extras-off** | 6 | 100% | 100% | 0.2196 | 2459 | 108802 | 24 | 5.5 | 4 (3–4) | 8 (7–9) | 100% | 0.0 | 37 |
| **extras-on** | 6 | 100% | 100% | 0.2140 | 2457 | 104660 | 18 | 5.3 | 3 (3–4) | 8 (7–8) | 100% | 0.0 | 35 |

## quiet-extras

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 6 | 100% | 100% | 0.2196 | 2459 | 108802 | 24 | 5.5 | 4 (3–4) | 8 (7–9) | 100% | 0.0 | 37 |
| extras-on | 6 | 100% | 100% | 0.2140 | 2457 | 104660 | 18 | 5.3 | 3 (3–4) | 8 (7–8) | 100% | 0.0 | 35 |

### Per-rep rows — quiet-extras

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 1 | PASS | ok | — | 0.2704 | 2890 | 49 | 3 | `node --test` | — | 148 | success |
| extras-off | 2 | PASS | ok | — | 0.2031 | 2201 | 34 | 4 | `node --test` | — | 130 | success |
| extras-off | 3 | PASS | ok | — | 0.2183 | 2760 | 38 | 3 | `node --test` | — | 161 | success |
| extras-off | 4 | PASS | ok | — | 0.1928 | 1909 | 9 | 4 | `node --test` | — | 131 | success |
| extras-off | 5 | PASS | ok | — | 0.2008 | 2280 | 7 | 3 | `node --test 2>&1 \| Select-Object -Last 30` | — | 152 | success |
| extras-off | 6 | PASS | ok | — | 0.2320 | 2713 | 6 | 4 | `node --test` | — | 158 | success |
| extras-on | 1 | PASS | ok | — | 0.2283 | 2916 | 9 | 4 | `node --test` | — | 186 | success |
| extras-on | 2 | PASS | ok | — | 0.2057 | 2378 | 15 | 3 | `node --test` | — | 150 | success |
| extras-on | 3 | PASS | ok | — | 0.2291 | 2702 | 24 | 3 | `node --test` | — | 202 | success |
| extras-on | 4 | PASS | ok | — | 0.2240 | 2530 | 24 | 3 | `node --test` | — | 163 | success |
| extras-on | 5 | PASS | ok | — | 0.1949 | 2053 | 8 | 3 | `node --test` | — | 157 | success |
| extras-on | 6 | PASS | ok | — | 0.2023 | 2163 | 25 | 4 | `node --test` | — | 156 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
