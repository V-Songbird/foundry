# foreman handoff benchmark — run `benefit-opus`

12 runs · model `opus` · generated from `results/benefit-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **pin-off** | 6 | 0% | 100% | 0.2079 | 1719 | 131727 | 7 | 5.2 | 2 (2–2) | 6 (6–7) | 100% | 3.0 | 23 |
| **pin-on** | 6 | 100% | 100% | 0.2204 | 1840 | 142663 | 9 | 5.5 | 3 (3–3) | 8 (7–8) | 100% | 0.0 | 28 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 6 | 0% | 100% | 0.2079 | 1719 | 131727 | 7 | 5.2 | 2 (2–2) | 6 (6–7) | 100% | 3.0 | 23 |
| pin-on | 6 | 100% | 100% | 0.2204 | 1840 | 142663 | 9 | 5.5 | 3 (3–3) | 8 (7–8) | 100% | 0.0 | 28 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2017 | 1578 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 69 | success |
| pin-off | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2057 | 1694 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 72 | success |
| pin-off | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2053 | 1740 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 59 | success |
| pin-off | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2215 | 1801 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 67 | success |
| pin-off | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2073 | 1744 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 84 | success |
| pin-off | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2058 | 1759 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 63 | success |
| pin-on | 1 | PASS | ok | — | 0.2127 | 1819 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 137 | success |
| pin-on | 2 | PASS | ok | — | 0.2006 | 1469 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 106 | success |
| pin-on | 3 | PASS | ok | — | 0.2334 | 1971 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 96 | success |
| pin-on | 4 | PASS | ok | — | 0.2055 | 1625 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 127 | success |
| pin-on | 5 | PASS | ok | — | 0.2388 | 2207 | 14 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 108 | success |
| pin-on | 6 | PASS | ok | — | 0.2312 | 1946 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 130 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
