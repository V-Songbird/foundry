# foreman handoff benchmark — run `wrong252-sonnet`

18 runs · model `sonnet` · generated from `results/wrong252-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **pin-off** | 6 | 0% | 100% | 0.2034 | 1409 | 150357 | 13 | 4.7 | 2 (2–2) | 6 (5–6) | 100% | 3.0 | 19 |
| **pin-on** | 6 | 100% | 100% | 0.1495 | 2016 | 134502 | 28 | 4.2 | 2 (2–3) | 5 (5–7) | 100% | 0.0 | 29 |
| **pin-wrong** | 6 | 0% | 100% | 0.1588 | 1948 | 157817 | 36 | 4.8 | 2 (2–2) | 6 (5–6) | 100% | 3.0 | 24 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 6 | 0% | 100% | 0.2034 | 1409 | 150357 | 13 | 4.7 | 2 (2–2) | 6 (5–6) | 100% | 3.0 | 19 |
| pin-on | 6 | 100% | 100% | 0.1495 | 2016 | 134502 | 28 | 4.2 | 2 (2–3) | 5 (5–7) | 100% | 0.0 | 29 |
| pin-wrong | 6 | 0% | 100% | 0.1588 | 1948 | 157817 | 36 | 4.8 | 2 (2–2) | 6 (5–6) | 100% | 3.0 | 24 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2474 | 1299 | 0 | 2 | `node --test` | — | 33 | success |
| pin-off | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2696 | 1476 | 28 | 2 | `node --test 2>&1` | — | 33 | success |
| pin-off | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2475 | 1301 | 0 | 2 | `node --test` | — | 29 | success |
| pin-off | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1519 | 1454 | 16 | 2 | `node --test 2>&1` | — | 35 | success |
| pin-off | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1517 | 1442 | 16 | 2 | `node --test 2>&1` | — | 36 | success |
| pin-off | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1525 | 1482 | 15 | 2 | `node --test 2>&1` | — | 36 | success |
| pin-on | 1 | PASS | ok | — | 0.1391 | 1678 | 0 | 2 | `node --test` | — | 85 | success |
| pin-on | 2 | PASS | ok | — | 0.1590 | 2608 | 48 | 2 | `node --test` | — | 68 | success |
| pin-on | 3 | PASS | ok | — | 0.2009 | 3707 | 0 | 3 | `node --test 2>&1` | — | 123 | success |
| pin-on | 4 | PASS | ok | — | 0.1254 | 1016 | 39 | 2 | `node --test` | — | 52 | success |
| pin-on | 5 | PASS | ok | — | 0.1460 | 1993 | 35 | 2 | `node --test` | — | 67 | success |
| pin-on | 6 | PASS | ok | — | 0.1267 | 1094 | 44 | 2 | `node --test` | — | 67 | success |
| pin-wrong | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1623 | 1918 | 0 | 2 | `node --test 2>&1` | — | 111 | success |
| pin-wrong | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1561 | 1967 | 48 | 2 | `node --test 2>&1 \| Select-Object -Last 40` | — | 106 | success |
| pin-wrong | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1475 | 2083 | 0 | 2 | `node --test` | — | 93 | success |
| pin-wrong | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1609 | 1857 | 48 | 2 | `node --test 2>&1` | — | 111 | success |
| pin-wrong | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1605 | 1821 | 62 | 2 | `node --test 2>&1` | — | 83 | success |
| pin-wrong | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1653 | 2041 | 58 | 2 | `node --test 2>&1` | — | 86 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
