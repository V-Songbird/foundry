# foreman handoff benchmark — run `ranked291-opus`

12 runs · model `opus` · generated from `results/ranked291-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **unpin-ranked** | 6 | 100% | 100% | 0.2205 | 2365 | 103731 | 7 | 5.0 | 3 (2–3) | 7 (7–7) | 100% | 0.0 | 31 |
| **unpin-wrong** | 6 | 83% | 100% | 0.3118 | 3089 | 128010 | 13 | 6.0 | 3 (2–3) | 8 (7–10) | 100% | 0.5 | 42 |

## unpinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-ranked | 6 | 100% | 100% | 0.2205 | 2365 | 103731 | 7 | 5.0 | 3 (2–3) | 7 (7–7) | 100% | 0.0 | 31 |
| unpin-wrong | 6 | 83% | 100% | 0.3118 | 3089 | 128010 | 13 | 6.0 | 3 (2–3) | 8 (7–10) | 100% | 0.5 | 42 |

### Per-rep rows — unpinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-ranked | 1 | PASS | ok | — | 0.2230 | 2453 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "exit=$LASTEXITC` | — | 144 | success |
| unpin-ranked | 2 | PASS | ok | — | 0.2139 | 2178 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 126 | success |
| unpin-ranked | 3 | PASS | ok | — | 0.2149 | 2262 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 127 | success |
| unpin-ranked | 4 | PASS | ok | — | 0.2191 | 2269 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 137 | success |
| unpin-ranked | 5 | PASS | ok | — | 0.2315 | 2690 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 151 | success |
| unpin-ranked | 6 | PASS | ok | — | 0.2205 | 2335 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 134 | success |
| unpin-wrong | 1 | PASS | ok | — | 0.3318 | 2536 | 31 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 166 | success |
| unpin-wrong | 2 | PASS | ok | — | 0.4388 | 4257 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 60; "EXIT=$LASTEXITC` | — | 157 | success |
| unpin-wrong | 3 | PASS | ok | — | 0.3283 | 2524 | 13 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 147 | success |
| unpin-wrong | 4 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.2643 | 3297 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 179 | success |
| unpin-wrong | 5 | PASS | ok | — | 0.2588 | 3108 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 171 | success |
| unpin-wrong | 6 | PASS | ok | — | 0.2487 | 2812 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 149 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
