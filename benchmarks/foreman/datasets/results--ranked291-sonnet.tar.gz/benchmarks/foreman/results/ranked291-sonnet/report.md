# foreman handoff benchmark — run `ranked291-sonnet`

12 runs · model `sonnet` · generated from `results/ranked291-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **unpin-ranked** | 6 | 33% | 100% | 0.1050 | 2536 | 118047 | 23 | 4.3 | 2 (2–3) | 6 (5–7) | 100% | 2.0 | 33 |
| **unpin-wrong** | 6 | 17% | 100% | 0.1313 | 2313 | 122195 | 18 | 4.5 | 3 (2–4) | 6 (5–8) | 100% | 2.5 | 31 |

## unpinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-ranked | 6 | 33% | 100% | 0.1050 | 2536 | 118047 | 23 | 4.3 | 2 (2–3) | 6 (5–7) | 100% | 2.0 | 33 |
| unpin-wrong | 6 | 17% | 100% | 0.1313 | 2313 | 122195 | 18 | 4.5 | 3 (2–4) | 6 (5–8) | 100% | 2.5 | 31 |

### Per-rep rows — unpinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-ranked | 1 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1148 | 3437 | 0 | 2 | `node --test` | — | 106 | success |
| unpin-ranked | 2 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0939 | 1953 | 51 | 2 | `node --test` | — | 69 | success |
| unpin-ranked | 3 | PASS | ok | — | 0.1308 | 4122 | 48 | 3 | `node --test` | — | 121 | success |
| unpin-ranked | 4 | PASS | ok | — | 0.1095 | 2258 | 0 | 3 | `node --test 2>&1` | — | 114 | success |
| unpin-ranked | 5 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0865 | 1429 | 37 | 2 | `node --test` | — | 68 | success |
| unpin-ranked | 6 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0944 | 2015 | 0 | 2 | `node --test` | — | 110 | success |
| unpin-wrong | 1 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1426 | 1350 | 35 | 2 | `node --test` | — | 58 | success |
| unpin-wrong | 2 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1793 | 3961 | 0 | 2 | `node --test 2>&1` | — | 117 | success |
| unpin-wrong | 3 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1573 | 2015 | 0 | 3 | `node --test` | — | 106 | success |
| unpin-wrong | 4 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0812 | 1050 | 33 | 2 | `node --test` | — | 54 | success |
| unpin-wrong | 5 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0828 | 1172 | 41 | 2 | `node --test` | — | 71 | success |
| unpin-wrong | 6 | PASS | ok | — | 0.1449 | 4330 | 0 | 4 | `node --test 2>&1` | — | 129 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
