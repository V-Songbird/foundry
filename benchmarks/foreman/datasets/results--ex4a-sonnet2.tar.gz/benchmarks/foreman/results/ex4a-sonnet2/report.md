# foreman handoff benchmark — run `ex4a-sonnet2`

12 runs · model `sonnet` · generated from `results/ex4a-sonnet2/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **extras-off** | 6 | 100% | 100% | 0.1000 | 1935 | 164500 | 12 | 6.5 | 3 (3–4) | 7 (6–8) | 100% | 0.0 | 27 |
| **extras-on** | 6 | 100% | 100% | 0.1127 | 2711 | 164172 | 1 | 6.3 | 4 (3–4) | 7 (6–8) | 100% | 0.0 | 42 |

## quiet-extras

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 6 | 100% | 100% | 0.1000 | 1935 | 164500 | 12 | 6.5 | 3 (3–4) | 7 (6–8) | 100% | 0.0 | 27 |
| extras-on | 6 | 100% | 100% | 0.1127 | 2711 | 164172 | 1 | 6.3 | 4 (3–4) | 7 (6–8) | 100% | 0.0 | 42 |

### Per-rep rows — quiet-extras

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 1 | PASS | ok | — | 0.0956 | 1829 | 0 | 3 | `node --test 2>&1` | — | 35 | success |
| extras-off | 2 | PASS | ok | — | 0.1028 | 1923 | 31 | 3 | `node --test 2>&1` | — | 39 | success |
| extras-off | 3 | PASS | ok | — | 0.1067 | 2200 | 20 | 3 | `node --test` | — | 31 | success |
| extras-off | 4 | PASS | ok | — | 0.0858 | 1144 | 14 | 3 | `node --test` | — | 37 | success |
| extras-off | 5 | PASS | ok | — | 0.1044 | 2017 | 4 | 4 | `node --test` | — | 41 | success |
| extras-off | 6 | PASS | ok | — | 0.1050 | 2494 | 0 | 3 | `node --test 2>&1` | — | 39 | success |
| extras-on | 1 | PASS | ok | — | 0.1000 | 2059 | 0 | 4 | `node --test 2>&1` | — | 41 | success |
| extras-on | 2 | PASS | ok | — | 0.1014 | 2168 | 0 | 3 | `node --test` | — | 32 | success |
| extras-on | 3 | PASS | ok | — | 0.1429 | 3584 | 5 | 3 | `node --test` | — | 35 | success |
| extras-on | 4 | PASS | ok | — | 0.1074 | 2601 | 0 | 3 | `node --test 2>&1` | — | 52 | success |
| extras-on | 5 | PASS | ok | — | 0.1145 | 3066 | 0 | 4 | `node --test 2>&1` | — | 35 | success |
| extras-on | 6 | PASS | ok | — | 0.1102 | 2787 | 0 | 4 | `node --test` | — | 54 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
