# foreman handoff benchmark — run `os42-opus`

16 runs · model `opus` · generated from `results/os42-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **shape-off** | 9 | 100% | 100% | 0.1813 | 1447 | 120612 | 37 | 5.0 | 3 (2–5) | 7 (6–8) | 100% | 0.0 | 24 |
| **shape-on** | 7 | 100% | 100% | 0.1887 | 1544 | 124927 | 32 | 5.1 | 4 (2–6) | 8 (6–9) | 100% | 0.0 | 25 |

## adjacent-mess

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 3 | 100% | 100% | 0.1705 | 1097 | 120790 | 14 | 5.0 | 2 (2–3) | 6 (6–7) | 100% | 0.0 | 21 |
| shape-on | 1 | 100% | 100% | 0.1717 | 1068 | 121064 | 6 | 5.0 | 2 (2–2) | 6 (6–6) | 100% | 0.0 | 20 |

### Per-rep rows — adjacent-mess

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 1 | PASS | ok | — | 0.1756 | 1172 | 20 | 3 | `node --test 2>&1 \| Select-Object -Last 25` | — | 119 | success |
| shape-off | 2 | PASS | ok | — | 0.1705 | 1141 | 17 | 2 | `node --test 2>&1 \| Select-Object -Last 30` | — | 151 | success |
| shape-off | 3 | PASS | ok | — | 0.1654 | 977 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 30` | — | 124 | success |
| shape-on | 1 | PASS | ok | — | 0.1717 | 1068 | 6 | 2 | `node --test` | — | 125 | success |

## api-constraint

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 3 | 100% | 100% | 0.1851 | 1471 | 121206 | 57 | 5.0 | 4 (3–4) | 7 (7–7) | 100% | 0.0 | 23 |
| shape-on | 3 | 100% | 100% | 0.1947 | 1505 | 130745 | 43 | 5.3 | 4 (3–6) | 8 (7–9) | 100% | 0.0 | 24 |

### Per-rep rows — api-constraint

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 1 | PASS | ok | — | 0.1833 | 1427 | 51 | 4 | `node --test` | — | 109 | success |
| shape-off | 2 | PASS | ok | — | 0.1867 | 1491 | 78 | 4 | `node --test` | — | 62 | success |
| shape-off | 3 | PASS | ok | — | 0.1854 | 1496 | 43 | 3 | `node --test 2>&1 \| Select-Object -Last 25` | — | 112 | success |
| shape-on | 1 | PASS | ok | — | 0.1794 | 1297 | 29 | 4 | `node --test` | — | 124 | success |
| shape-on | 2 | PASS | ok | — | 0.2142 | 1670 | 54 | 6 | `node --test` | — | 119 | success |
| shape-on | 3 | PASS | ok | — | 0.1903 | 1548 | 46 | 3 | `node --test` | — | 132 | success |

## moved-file

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 3 | 100% | 100% | 0.1884 | 1772 | 119839 | 39 | 5.0 | 4 (4–5) | 8 (8–8) | 100% | 0.0 | 27 |
| shape-on | 3 | 100% | 100% | 0.1883 | 1741 | 120396 | 29 | 5.0 | 4 (4–5) | 8 (8–8) | 100% | 0.0 | 28 |

### Per-rep rows — moved-file

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 1 | PASS | ok | — | 0.1955 | 1970 | 7 | 4 | `node --test` | yes | 172 | success |
| shape-off | 2 | PASS | ok | — | 0.1880 | 1731 | 46 | 4 | `node --test 2>&1 \| Select-Object -Last 25` | yes | 78 | success |
| shape-off | 3 | PASS | ok | — | 0.1816 | 1616 | 64 | 5 | `node --test` | yes | 167 | success |
| shape-on | 1 | PASS | ok | — | 0.1829 | 1684 | 35 | 5 | `node --test 2>&1 \| Select-Object -Last 25` | yes | 191 | success |
| shape-on | 2 | PASS | ok | — | 0.1911 | 1798 | 25 | 4 | `node --test` | yes | 165 | success |
| shape-on | 3 | PASS | ok | — | 0.1910 | 1741 | 27 | 4 | `node --test` | yes | 101 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
