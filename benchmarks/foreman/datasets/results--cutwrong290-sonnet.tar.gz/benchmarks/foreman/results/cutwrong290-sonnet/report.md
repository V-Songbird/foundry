# foreman handoff benchmark — run `cutwrong290-sonnet`

12 runs · model `sonnet` · generated from `results/cutwrong290-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **cut-wrong** | 6 | 0% | 100% | 0.0906 | 1762 | 106190 | 22 | 4.0 | 2 (2–2) | 5 (5–5) | 100% | 3.0 | 24 |
| **unpin-wrong** | 6 | 17% | 100% | 0.0999 | 2035 | 122292 | 15 | 4.5 | 2 (2–3) | 6 (5–7) | 100% | 2.5 | 29 |

## unpinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-wrong | 6 | 0% | 100% | 0.0906 | 1762 | 106190 | 22 | 4.0 | 2 (2–2) | 5 (5–5) | 100% | 3.0 | 24 |
| unpin-wrong | 6 | 17% | 100% | 0.0999 | 2035 | 122292 | 15 | 4.5 | 2 (2–3) | 6 (5–7) | 100% | 2.5 | 29 |

### Per-rep rows — unpinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-wrong | 1 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0810 | 1078 | 57 | 2 | `node --test` | — | 42 | success |
| cut-wrong | 2 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1017 | 2551 | 0 | 2 | `node --test` | — | 63 | success |
| cut-wrong | 3 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0767 | 774 | 37 | 2 | `node --test` | — | 37 | success |
| cut-wrong | 4 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1112 | 3216 | 36 | 2 | `node --test` | — | 57 | success |
| cut-wrong | 5 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0803 | 1042 | 0 | 2 | `node --test` | — | 59 | success |
| cut-wrong | 6 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0927 | 1910 | 0 | 2 | `node --test` | — | 47 | success |
| unpin-wrong | 1 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1181 | 3687 | 0 | 2 | `node --test` | — | 108 | success |
| unpin-wrong | 2 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0850 | 1333 | 0 | 2 | `node --test` | — | 79 | success |
| unpin-wrong | 3 | PASS | ok | — | 0.1214 | 3090 | 51 | 3 | `node --test 2>&1` | — | 107 | success |
| unpin-wrong | 4 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0871 | 1471 | 0 | 2 | `node --test` | — | 72 | success |
| unpin-wrong | 5 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1090 | 1772 | 10 | 2 | `node --test 2>&1` | — | 87 | success |
| unpin-wrong | 6 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0784 | 856 | 28 | 2 | `node --test` | — | 54 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
