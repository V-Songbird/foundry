# foreman handoff benchmark — run `unpin289-opus`

12 runs · model `opus` · generated from `results/unpin289-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **unpin-off** | 6 | 100% | 100% | 0.2007 | 1760 | 108320 | 8 | 5.3 | 2 (2–2) | 6 (6–7) | 100% | 0.0 | 24 |
| **unpin-wrong** | 6 | 100% | 100% | 0.2559 | 3062 | 123816 | 13 | 5.8 | 3 (3–4) | 8 (7–10) | 100% | 0.0 | 40 |

## unpinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-off | 6 | 100% | 100% | 0.2007 | 1760 | 108320 | 8 | 5.3 | 2 (2–2) | 6 (6–7) | 100% | 0.0 | 24 |
| unpin-wrong | 6 | 100% | 100% | 0.2559 | 3062 | 123816 | 13 | 5.8 | 3 (3–4) | 8 (7–10) | 100% | 0.0 | 40 |

### Per-rep rows — unpinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-off | 1 | PASS | ok | — | 0.1978 | 1777 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 55 | success |
| unpin-off | 2 | PASS | ok | — | 0.2161 | 1987 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 81 | success |
| unpin-off | 3 | PASS | ok | — | 0.1919 | 1620 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 71 | success |
| unpin-off | 4 | PASS | ok | — | 0.1910 | 1588 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 60 | success |
| unpin-off | 5 | PASS | ok | — | 0.2162 | 1977 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 76 | success |
| unpin-off | 6 | PASS | ok | — | 0.1913 | 1611 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 74 | success |
| unpin-wrong | 1 | PASS | ok | — | 0.2355 | 2798 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 137 | success |
| unpin-wrong | 2 | PASS | ok | — | 0.2647 | 3222 | 10 | 4 | `node --test 2>&1 \| Select-Object -Last 30` | — | 175 | success |
| unpin-wrong | 3 | PASS | ok | — | 0.3143 | 3939 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 163 | success |
| unpin-wrong | 4 | PASS | ok | — | 0.2494 | 2800 | 10 | 4 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 153 | success |
| unpin-wrong | 5 | PASS | ok | — | 0.2333 | 2745 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 142 | success |
| unpin-wrong | 6 | PASS | ok | — | 0.2382 | 2869 | 37 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 127 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
