# picks mini-benchmark — run `proof2`

Stability ("distinct picks out of 5") and cost of answering "what should I work on next?" per backlog size.

Distinct counts are over NORMALIZED picks (markdown emphasis, trailing ` (#NNN)` ids, surrounding quotes/punctuation, whitespace, and case stripped) — the headline number. Raw distinct is shown for reference; raw strings stay in records.json.

| Size | Arm | Distinct (normalized) / 5 | Distinct (raw) | Deterministic | Mean output tok | Mean cost USD | Top pick |
|---|---|---|---|---|---|---|---|
| 10 | foreman | 1/5 | 1/5 | yes | 0 | 0 | Migrate the session store config to the shared loader |
| 10 | markdown | 2/5 | 2/5 | no | 1143 | 0.057887999999999995 | Fix timezone handling in i18n |
| 50 | foreman | 1/5 | 1/5 | yes | 0 | 0 | Fix pagination drift in uploads |
| 50 | markdown | 1/5 | 1/5 | yes | 1111.4 | 0.0737582 | Tighten error messages in the admin dashboard |
| 150 | foreman | 1/5 | 1/5 | yes | 0 | 0 | Fix pagination drift in i18n |
| 150 | markdown | 1/5 | 1/5 | yes | 1647.6 | 0.12739132 | Add retry backoff to exports |

The foreman arm is `roadmap.js next-candidates` — mechanical graph filtering, zero tokens, no LLM in the loop.
