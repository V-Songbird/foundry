# foreman handoff benchmark — run `benefit-sonnet`

12 runs · model `sonnet` · generated from `results/benefit-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **pin-off** | 6 | 0% | 100% | 0.1434 | 1493 | 144626 | 9 | 4.5 | 2 (2–2) | 6 (5–6) | 100% | 3.0 | 18 |
| **pin-on** | 6 | 100% | 100% | 0.1529 | 2032 | 140548 | 15 | 4.3 | 2 (2–3) | 6 (5–7) | 100% | 0.0 | 28 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 6 | 0% | 100% | 0.1434 | 1493 | 144626 | 9 | 4.5 | 2 (2–2) | 6 (5–6) | 100% | 3.0 | 18 |
| pin-on | 6 | 100% | 100% | 0.1529 | 2032 | 140548 | 15 | 4.3 | 2 (2–3) | 6 (5–7) | 100% | 0.0 | 28 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1306 | 1324 | 0 | 2 | `node --test` | — | 35 | success |
| pin-off | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1317 | 1386 | 0 | 2 | `node --test` | — | 51 | success |
| pin-off | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1524 | 1479 | 24 | 2 | `node --test 2>&1` | — | 41 | success |
| pin-off | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1528 | 1503 | 16 | 2 | `node --test 2>&1` | — | 38 | success |
| pin-off | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1615 | 1908 | 16 | 2 | `node --test 2>&1` | — | 46 | success |
| pin-off | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1313 | 1360 | 0 | 2 | `node --test` | — | 41 | success |
| pin-on | 1 | PASS | ok | — | 0.1250 | 1006 | 34 | 2 | `node --test` | — | 58 | success |
| pin-on | 2 | PASS | ok | — | 0.1296 | 1237 | 0 | 2 | `node --test` | — | 86 | success |
| pin-on | 3 | PASS | ok | — | 0.1758 | 2519 | 0 | 3 | `node --test 2>&1` | — | 103 | success |
| pin-on | 4 | PASS | ok | — | 0.1813 | 2783 | 26 | 3 | `node --test 2>&1` | — | 100 | success |
| pin-on | 5 | PASS | ok | — | 0.1245 | 985 | 29 | 2 | `node --test` | — | 68 | success |
| pin-on | 6 | PASS | ok | — | 0.1813 | 3664 | 0 | 2 | `node --test` | — | 94 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
