# foreman handoff benchmark — run `p2-lessons-haiku`

16 runs · model `haiku` · generated from `results/p2-lessons-haiku/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **lessons-control** | 4 | 100% | 100% | 0.0804 | 3196 | 168647 | 75 | 6.8 | 4 (4–4) | 8 (8–8) | 100% | 0.0 | 37 |
| **lessons-fresh** | 4 | 100% | 100% | 0.0582 | 2993 | 174347 | 64 | 7.0 | 4 (4–4) | 8 (8–8) | 100% | 0.0 | 35 |
| **lessons-graded** | 4 | 100% | 100% | 0.0617 | 3391 | 182110 | 84 | 7.3 | 5 (4–5) | 9 (8–9) | 100% | 0.0 | 39 |
| **lessons-unlabeled** | 4 | 100% | 100% | 0.0588 | 2992 | 180675 | 65 | 7.3 | 4 (4–5) | 8 (8–9) | 100% | 0.0 | 36 |

## moved-file

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| lessons-control | 4 | 100% | 100% | 0.0804 | 3196 | 168647 | 75 | 6.8 | 4 (4–4) | 8 (8–8) | 100% | 0.0 | 37 |
| lessons-fresh | 4 | 100% | 100% | 0.0582 | 2993 | 174347 | 64 | 7.0 | 4 (4–4) | 8 (8–8) | 100% | 0.0 | 35 |
| lessons-graded | 4 | 100% | 100% | 0.0617 | 3391 | 182110 | 84 | 7.3 | 5 (4–5) | 9 (8–9) | 100% | 0.0 | 39 |
| lessons-unlabeled | 4 | 100% | 100% | 0.0588 | 2992 | 180675 | 65 | 7.3 | 4 (4–5) | 8 (8–9) | 100% | 0.0 | 36 |

### Per-rep rows — moved-file

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| lessons-control | 1 | PASS | ok | — | 0.0900 | 3414 | 52 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 25 | success |
| lessons-control | 2 | PASS | ok | — | 0.0867 | 2968 | 90 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 73 | success |
| lessons-control | 3 | PASS | ok | — | 0.0921 | 3736 | 81 | 4 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 42 | success |
| lessons-control | 4 | PASS | ok | — | 0.0529 | 2666 | 76 | 4 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 51 | success |
| lessons-fresh | 1 | PASS | ok | — | 0.0578 | 2928 | 60 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 40 | success |
| lessons-fresh | 2 | PASS | ok | — | 0.0683 | 4426 | 90 | 4 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 78 | success |
| lessons-fresh | 3 | PASS | ok | — | 0.0538 | 2373 | 51 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 29 | success |
| lessons-fresh | 4 | PASS | ok | — | 0.0529 | 2244 | 53 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 61 | success |
| lessons-graded | 1 | PASS | ok | — | 0.0629 | 3325 | 67 | 5 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 59 | success |
| lessons-graded | 2 | PASS | ok | — | 0.0648 | 3952 | 91 | 4 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 50 | success |
| lessons-graded | 3 | PASS | ok | — | 0.0568 | 3106 | 86 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 52 | success |
| lessons-graded | 4 | PASS | ok | — | 0.0621 | 3179 | 91 | 5 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 73 | success |
| lessons-unlabeled | 1 | PASS | ok | — | 0.0601 | 3282 | 51 | 4 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | yes | 89 | success |
| lessons-unlabeled | 2 | PASS | ok | — | 0.0628 | 3633 | 64 | 4 | `cd 'X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | yes | 76 | success |
| lessons-unlabeled | 3 | PASS | ok | — | 0.0590 | 2750 | 85 | 5 | `node --test` | no | 60 | success |
| lessons-unlabeled | 4 | PASS | ok | — | 0.0534 | 2302 | 58 | 4 | `cd "X:\Temp\foreman-bench\p2-lessons-haiku\moved-file__lesso` | no | 49 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
