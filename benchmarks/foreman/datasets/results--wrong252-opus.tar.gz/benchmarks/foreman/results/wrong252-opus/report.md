# foreman handoff benchmark — run `wrong252-opus`

18 runs · model `opus` · generated from `results/wrong252-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **pin-off** | 6 | 0% | 100% | 0.2943 | 1813 | 136802 | 6 | 5.3 | 2 (2–2) | 6 (6–7) | 100% | 3.0 | 26 |
| **pin-on** | 6 | 100% | 100% | 0.2454 | 2316 | 157599 | 7 | 6.0 | 3 (2–4) | 8 (7–10) | 100% | 0.0 | 39 |
| **pin-wrong** | 6 | 0% | 100% | 0.2201 | 2012 | 133494 | 9 | 5.2 | 3 (2–3) | 7 (6–7) | 100% | 3.0 | 28 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 6 | 0% | 100% | 0.2943 | 1813 | 136802 | 6 | 5.3 | 2 (2–2) | 6 (6–7) | 100% | 3.0 | 26 |
| pin-on | 6 | 100% | 100% | 0.2454 | 2316 | 157599 | 7 | 6.0 | 3 (2–4) | 8 (7–10) | 100% | 0.0 | 39 |
| pin-wrong | 6 | 0% | 100% | 0.2201 | 2012 | 133494 | 9 | 5.2 | 3 (2–3) | 7 (6–7) | 100% | 3.0 | 28 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pin-off | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.3885 | 1964 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 72 | success |
| pin-off | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.3669 | 1766 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 75 | success |
| pin-off | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.3835 | 1820 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 68 | success |
| pin-off | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2172 | 2008 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 63 | success |
| pin-off | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2038 | 1637 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 69 | success |
| pin-off | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2059 | 1683 | 0 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 57 | success |
| pin-on | 1 | PASS | ok | — | 0.2867 | 3012 | 10 | 4 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 158 | success |
| pin-on | 2 | PASS | ok | — | 0.2343 | 2003 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 115 | success |
| pin-on | 3 | PASS | ok | — | 0.2314 | 2360 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 130 | success |
| pin-on | 4 | PASS | ok | — | 0.2478 | 2430 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 155 | success |
| pin-on | 5 | PASS | ok | — | 0.2378 | 2070 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 113 | success |
| pin-on | 6 | PASS | ok | — | 0.2342 | 2022 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 150 | success |
| pin-wrong | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2194 | 2019 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 111 | success |
| pin-wrong | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2210 | 2135 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 130 | success |
| pin-wrong | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2180 | 2035 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 105 | success |
| pin-wrong | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2325 | 2015 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 144 | success |
| pin-wrong | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2189 | 2017 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 136 | success |
| pin-wrong | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2106 | 1853 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 30; "exit=$LASTEXITC` | — | 116 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
