# foreman handoff benchmark — run `chain288-sonnet`

12 runs · model `sonnet` · generated from `results/chain288-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **chain-off** | 6 | 0% | 100% | 0.0873 | 1416 | 110314 | 9 | 4.2 | 2 (2–2) | 5 (5–6) | 100% | 3.0 | 19 |
| **chain-on** | 6 | 100% | 100% | 0.1019 | 2571 | 107752 | 6 | 4.0 | 2 (2–2) | 5 (5–5) | 100% | 0.0 | 32 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| chain-off | 6 | 0% | 100% | 0.0873 | 1416 | 110314 | 9 | 4.2 | 2 (2–2) | 5 (5–6) | 100% | 3.0 | 19 |
| chain-on | 6 | 100% | 100% | 0.1019 | 2571 | 107752 | 6 | 4.0 | 2 (2–2) | 5 (5–5) | 100% | 0.0 | 32 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| chain-off | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.0837 | 1289 | 16 | 2 | `node --test` | — | 33 | success |
| chain-off | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.0884 | 1628 | 0 | 2 | `node --test` | — | 38 | success |
| chain-off | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.0972 | 1450 | 40 | 2 | `node --test 2>&1` | — | 36 | success |
| chain-off | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.0847 | 1369 | 0 | 2 | `node --test` | — | 39 | success |
| chain-off | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.0851 | 1397 | 0 | 2 | `node --test` | — | 43 | success |
| chain-off | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.0847 | 1362 | 0 | 2 | `node --test` | — | 34 | success |
| chain-on | 1 | PASS | ok | — | 0.1166 | 3601 | 0 | 2 | `node --test` | — | 90 | success |
| chain-on | 2 | PASS | ok | — | 0.1111 | 3236 | 0 | 2 | `node --test` | — | 108 | success |
| chain-on | 3 | PASS | ok | — | 0.0982 | 2303 | 0 | 2 | `node --test` | — | 68 | success |
| chain-on | 4 | PASS | ok | — | 0.0944 | 2047 | 0 | 2 | `node --test` | — | 100 | success |
| chain-on | 5 | PASS | ok | — | 0.1002 | 2437 | 33 | 2 | `node --test` | — | 58 | success |
| chain-on | 6 | PASS | ok | — | 0.0910 | 1799 | 0 | 2 | `node --test` | — | 78 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
