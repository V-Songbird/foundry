# foreman handoff benchmark — run `ex4a-opus`

12 runs · model `opus` · generated from `results/ex4a-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **extras-off** | 6 | 100% | 100% | 0.1720 | 478 | 71476 | 14 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |
| **extras-on** | 6 | 100% | 100% | 0.1364 | 671 | 82983 | 16 | 4.5 | 2 (1–4) | 6 (4–8) | 100% | 0.0 | 13 |

## quiet-extras

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 6 | 100% | 100% | 0.1720 | 478 | 71476 | 14 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |
| extras-on | 6 | 100% | 100% | 0.1364 | 671 | 82983 | 16 | 4.5 | 2 (1–4) | 6 (4–8) | 100% | 0.0 | 13 |

### Per-rep rows — quiet-extras

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 1 | PASS | ok | — | 0.2261 | 502 | 19 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 26 | success |
| extras-off | 2 | PASS | ok | — | 0.2255 | 489 | 20 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 31 | success |
| extras-off | 3 | PASS | ok | — | 0.2235 | 428 | 0 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 31 | success |
| extras-off | 4 | PASS | ok | — | 0.1195 | 492 | 21 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 27 | success |
| extras-off | 5 | PASS | ok | — | 0.1172 | 433 | 5 | 1 | `node --test` | — | 32 | success |
| extras-off | 6 | PASS | ok | — | 0.1202 | 523 | 20 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 38 | success |
| extras-on | 1 | PASS | ok | — | 0.1536 | 909 | 23 | 3 | `node --test` | — | 67 | success |
| extras-on | 2 | PASS | ok | — | 0.1408 | 630 | 0 | 2 | `node --test 2>&1 \| Select-Object -Last 30` | — | 34 | success |
| extras-on | 3 | PASS | ok | — | 0.1220 | 512 | 18 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 31 | success |
| extras-on | 4 | PASS | ok | — | 0.1224 | 536 | 28 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 47 | success |
| extras-on | 5 | PASS | ok | — | 0.1207 | 475 | 18 | 1 | `node --test 2>&1 \| Select-Object -Last 40` | — | 30 | success |
| extras-on | 6 | PASS | ok | — | 0.1590 | 961 | 6 | 4 | `node --test` | — | 74 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
