# foreman handoff benchmark — run `os42-sonnet`

18 runs · model `sonnet` · generated from `results/os42-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **shape-off** | 9 | 100% | 100% | 0.1678 | 1045 | 164780 | 19 | 5.4 | 3 (1–6) | 6 (4–9) | 100% | 0.0 | 16 |
| **shape-on** | 9 | 100% | 100% | 0.1406 | 1236 | 186079 | 17 | 6.1 | 4 (2–8) | 7 (5–11) | 100% | 0.0 | 18 |

## adjacent-mess

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 3 | 100% | 100% | 0.1050 | 604 | 119838 | 11 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |
| shape-on | 3 | 100% | 100% | 0.1345 | 925 | 182806 | 21 | 6.0 | 3 (3–3) | 6 (6–6) | 100% | 0.0 | 16 |

### Per-rep rows — adjacent-mess

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 1 | PASS | ok | — | 0.1056 | 621 | 33 | 1 | `node --test` | — | 22 | success |
| shape-off | 2 | PASS | ok | — | 0.1050 | 614 | 0 | 1 | `node --test` | — | 48 | success |
| shape-off | 3 | PASS | ok | — | 0.1044 | 578 | 0 | 1 | `node --test` | — | 46 | success |
| shape-on | 1 | PASS | ok | — | 0.1326 | 841 | 12 | 3 | `node --test` | — | 64 | success |
| shape-on | 2 | PASS | ok | — | 0.1374 | 1075 | 13 | 3 | `node --test` | — | 74 | success |
| shape-on | 3 | PASS | ok | — | 0.1334 | 858 | 37 | 3 | `node --test` | — | 39 | success |

## api-constraint

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 3 | 100% | 100% | 0.2541 | 1067 | 183133 | 37 | 6.0 | 4 (3–5) | 7 (6–8) | 100% | 0.0 | 18 |
| shape-on | 3 | 100% | 100% | 0.1305 | 1064 | 162675 | 31 | 5.3 | 3 (2–4) | 6 (5–7) | 100% | 0.0 | 17 |

### Per-rep rows — api-constraint

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 1 | PASS | ok | — | 0.2599 | 1269 | 37 | 5 | `node --test` | — | 47 | success |
| shape-off | 2 | PASS | ok | — | 0.2519 | 999 | 25 | 3 | `node --test` | — | 39 | success |
| shape-off | 3 | PASS | ok | — | 0.2505 | 934 | 50 | 3 | `node --test` | — | 36 | success |
| shape-on | 1 | PASS | ok | — | 0.1323 | 1243 | 38 | 4 | `node --test` | — | 82 | success |
| shape-on | 2 | PASS | ok | — | 0.1208 | 860 | 30 | 2 | `node --test` | — | 63 | success |
| shape-on | 3 | PASS | ok | — | 0.1385 | 1089 | 26 | 4 | `node --test` | — | 75 | success |

## moved-file

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 3 | 100% | 100% | 0.1443 | 1464 | 191370 | 9 | 6.3 | 5 (5–6) | 8 (8–9) | 100% | 0.0 | 20 |
| shape-on | 3 | 100% | 100% | 0.1567 | 1719 | 212757 | 0 | 7.0 | 6 (5–8) | 9 (8–11) | 100% | 0.0 | 23 |

### Per-rep rows — moved-file

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| shape-off | 1 | PASS | ok | — | 0.1450 | 1673 | 0 | 5 | `node --test 2>&1` | no | 73 | success |
| shape-off | 2 | PASS | ok | — | 0.1452 | 1225 | 26 | 5 | `node --test` | no | 26 | success |
| shape-off | 3 | PASS | ok | — | 0.1426 | 1495 | 0 | 6 | `node --test` | no | 71 | success |
| shape-on | 1 | PASS | ok | — | 0.1771 | 2136 | 0 | 8 | `node --test 2>&1` | yes | 72 | success |
| shape-on | 2 | PASS | ok | — | 0.1563 | 1751 | 0 | 5 | `node --test` | no | 56 | success |
| shape-on | 3 | PASS | ok | — | 0.1367 | 1270 | 0 | 5 | `node --test` | no | 70 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
