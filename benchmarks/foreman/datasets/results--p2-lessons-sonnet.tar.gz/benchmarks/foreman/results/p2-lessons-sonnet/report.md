# foreman handoff benchmark — run `p2-lessons-sonnet`

16 runs · model `sonnet` · generated from `results/p2-lessons-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **lessons-control** | 4 | 100% | 100% | 0.2518 | 1389 | 215612 | 23 | 6.8 | 4 (4–5) | 9 (8–9) | 100% | 0.0 | 20 |
| **lessons-fresh** | 4 | 100% | 100% | 0.1623 | 1399 | 215519 | 29 | 6.8 | 5 (4–6) | 9 (8–10) | 100% | 0.0 | 21 |
| **lessons-graded** | 4 | 100% | 100% | 0.1731 | 1643 | 224986 | 25 | 7.0 | 5 (5–6) | 9 (9–10) | 100% | 0.0 | 22 |
| **lessons-unlabeled** | 4 | 100% | 100% | 0.1691 | 1581 | 217237 | 30 | 6.8 | 5 (4–6) | 9 (8–10) | 100% | 0.0 | 22 |

## moved-file

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| lessons-control | 4 | 100% | 100% | 0.2518 | 1389 | 215612 | 23 | 6.8 | 4 (4–5) | 9 (8–9) | 100% | 0.0 | 20 |
| lessons-fresh | 4 | 100% | 100% | 0.1623 | 1399 | 215519 | 29 | 6.8 | 5 (4–6) | 9 (8–10) | 100% | 0.0 | 21 |
| lessons-graded | 4 | 100% | 100% | 0.1731 | 1643 | 224986 | 25 | 7.0 | 5 (5–6) | 9 (9–10) | 100% | 0.0 | 22 |
| lessons-unlabeled | 4 | 100% | 100% | 0.1691 | 1581 | 217237 | 30 | 6.8 | 5 (4–6) | 9 (8–10) | 100% | 0.0 | 22 |

### Per-rep rows — moved-file

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| lessons-control | 1 | PASS | ok | — | 0.2855 | 1482 | 37 | 5 | `node --test 2>&1` | yes | 44 | success |
| lessons-control | 2 | PASS | ok | — | 0.2740 | 1398 | 20 | 4 | `node --test 2>&1` | yes | 55 | success |
| lessons-control | 3 | PASS | ok | — | 0.2802 | 1282 | 13 | 4 | `node --test 2>&1` | yes | 70 | success |
| lessons-control | 4 | PASS | ok | — | 0.1673 | 1394 | 23 | 4 | `node --test 2>&1` | yes | 58 | success |
| lessons-fresh | 1 | PASS | ok | — | 0.1596 | 1453 | 31 | 4 | `node --test 2>&1` | yes | 58 | success |
| lessons-fresh | 2 | PASS | ok | — | 0.1707 | 1462 | 26 | 6 | `node --test 2>&1` | yes | 51 | success |
| lessons-fresh | 3 | PASS | ok | — | 0.1631 | 1501 | 35 | 6 | `node --test 2>&1 \| Select-String -Pattern "tests\|pass\|fai` | yes | 64 | success |
| lessons-fresh | 4 | PASS | ok | — | 0.1559 | 1181 | 24 | 4 | `node --test 2>&1 \| Select-Object -Last 40` | yes | 50 | success |
| lessons-graded | 1 | PASS | ok | — | 0.1767 | 1842 | 0 | 5 | `node --test 2>&1` | yes | 80 | success |
| lessons-graded | 2 | PASS | ok | — | 0.1713 | 1539 | 56 | 5 | `node --test 2>&1` | yes | 68 | success |
| lessons-graded | 3 | PASS | ok | — | 0.1749 | 1686 | 19 | 6 | `node --test 2>&1` | yes | 74 | success |
| lessons-graded | 4 | PASS | ok | — | 0.1697 | 1506 | 24 | 5 | `node --test 2>&1` | yes | 84 | success |
| lessons-unlabeled | 1 | PASS | ok | — | 0.1771 | 1797 | 36 | 4 | `node --test 2>&1` | yes | 72 | success |
| lessons-unlabeled | 2 | PASS | ok | — | 0.1662 | 1374 | 60 | 4 | `node --test 2>&1` | yes | 64 | success |
| lessons-unlabeled | 3 | PASS | ok | — | 0.1733 | 1647 | 0 | 6 | `node --test 2>&1` | yes | 68 | success |
| lessons-unlabeled | 4 | PASS | ok | — | 0.1599 | 1507 | 22 | 4 | `node --test 2>&1 \| Out-String` | yes | 67 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
