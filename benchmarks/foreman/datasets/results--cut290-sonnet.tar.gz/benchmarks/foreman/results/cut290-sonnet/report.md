# foreman handoff benchmark — run `cut290-sonnet`

12 runs · model `sonnet` · generated from `results/cut290-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **cut-on** | 6 | 100% | 100% | 0.0859 | 1309 | 110261 | 12 | 4.2 | 2 (2–2) | 5 (5–6) | 100% | 0.0 | 19 |
| **pin-on** | 6 | 100% | 100% | 0.1152 | 1446 | 105920 | 27 | 4.0 | 2 (2–2) | 5 (5–5) | 100% | 0.0 | 23 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-on | 6 | 100% | 100% | 0.0859 | 1309 | 110261 | 12 | 4.2 | 2 (2–2) | 5 (5–6) | 100% | 0.0 | 19 |
| pin-on | 6 | 100% | 100% | 0.1152 | 1446 | 105920 | 27 | 4.0 | 2 (2–2) | 5 (5–5) | 100% | 0.0 | 23 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-on | 1 | PASS | ok | — | 0.0791 | 977 | 7 | 2 | `node --test` | — | 47 | success |
| cut-on | 2 | PASS | ok | — | 0.0923 | 1094 | 35 | 2 | `node --test 2>&1` | — | 54 | success |
| cut-on | 3 | PASS | ok | — | 0.0833 | 1247 | 0 | 2 | `node --test` | — | 52 | success |
| cut-on | 4 | PASS | ok | — | 0.0846 | 1346 | 32 | 2 | `node --test` | — | 49 | success |
| cut-on | 5 | PASS | ok | — | 0.0979 | 2288 | 0 | 2 | `node --test` | — | 57 | success |
| cut-on | 6 | PASS | ok | — | 0.0784 | 899 | 0 | 2 | `node --test` | — | 41 | success |
| pin-on | 1 | PASS | ok | — | 0.1539 | 2172 | 0 | 2 | `node --test` | — | 94 | success |
| pin-on | 2 | PASS | ok | — | 0.1454 | 1548 | 36 | 2 | `node --test` | — | 55 | success |
| pin-on | 3 | PASS | ok | — | 0.1356 | 873 | 60 | 2 | `node --test` | — | 78 | success |
| pin-on | 4 | PASS | ok | — | 0.0807 | 1018 | 32 | 2 | `node --test` | — | 56 | success |
| pin-on | 5 | PASS | ok | — | 0.0881 | 1551 | 35 | 2 | `node --test` | — | 62 | success |
| pin-on | 6 | PASS | ok | — | 0.0875 | 1516 | 0 | 2 | `node --test` | — | 77 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
