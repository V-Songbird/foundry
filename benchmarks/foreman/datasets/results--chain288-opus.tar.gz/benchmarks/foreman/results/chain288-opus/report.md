# foreman handoff benchmark — run `chain288-opus`

12 runs · model `opus` · generated from `results/chain288-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **chain-off** | 6 | 0% | 100% | 0.2499 | 1692 | 101391 | 7 | 5.0 | 2 (2–2) | 6 (6–7) | 100% | 3.0 | 23 |
| **chain-on** | 6 | 100% | 100% | 0.1987 | 1759 | 105229 | 7 | 5.2 | 2 (2–3) | 6 (6–7) | 100% | 0.0 | 28 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| chain-off | 6 | 0% | 100% | 0.2499 | 1692 | 101391 | 7 | 5.0 | 2 (2–2) | 6 (6–7) | 100% | 3.0 | 23 |
| chain-on | 6 | 100% | 100% | 0.1987 | 1759 | 105229 | 7 | 5.2 | 2 (2–3) | 6 (6–7) | 100% | 0.0 | 28 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| chain-off | 1 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.2963 | 1585 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 76 | success |
| chain-off | 2 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.3107 | 1928 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 71 | success |
| chain-off | 3 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.3214 | 1878 | 10 | 2 | `node --test; "EXIT=$LASTEXITCODE"` | — | 79 | success |
| chain-off | 4 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1878 | 1514 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 66 | success |
| chain-off | 5 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1940 | 1681 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 66 | success |
| chain-off | 6 | FAIL | ok | sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim; sentinel: src/stats.js no longer contains the pinned line verbatim | 0.1894 | 1568 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 73 | success |
| chain-on | 1 | PASS | ok | — | 0.2097 | 2075 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 123 | success |
| chain-on | 2 | PASS | ok | — | 0.1975 | 1763 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 107 | success |
| chain-on | 3 | PASS | ok | — | 0.2071 | 1712 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 103 | success |
| chain-on | 4 | PASS | ok | — | 0.1934 | 1663 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 113 | success |
| chain-on | 5 | PASS | ok | — | 0.1968 | 1800 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 102 | success |
| chain-on | 6 | PASS | ok | — | 0.1874 | 1541 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 101 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
