# foreman handoff benchmark — run `cut290-opus`

12 runs · model `opus` · generated from `results/cut290-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **cut-on** | 6 | 100% | 100% | 0.2052 | 1727 | 116196 | 9 | 5.7 | 2 (2–3) | 7 (6–8) | 100% | 0.0 | 26 |
| **pin-on** | 6 | 100% | 100% | 0.2655 | 1908 | 116922 | 7 | 5.7 | 3 (2–3) | 7 (7–8) | 100% | 0.0 | 29 |

## pinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-on | 6 | 100% | 100% | 0.2052 | 1727 | 116196 | 9 | 5.7 | 2 (2–3) | 7 (6–8) | 100% | 0.0 | 26 |
| pin-on | 6 | 100% | 100% | 0.2655 | 1908 | 116922 | 7 | 5.7 | 3 (2–3) | 7 (7–8) | 100% | 0.0 | 29 |

### Per-rep rows — pinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-on | 1 | PASS | ok | — | 0.1848 | 1437 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "exit=$LASTEXITC` | — | 129 | success |
| cut-on | 2 | PASS | ok | — | 0.2162 | 1864 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 60; "EXIT=$LASTEXITC` | — | 107 | success |
| cut-on | 3 | PASS | ok | — | 0.2225 | 2030 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 98 | success |
| cut-on | 4 | PASS | ok | — | 0.2107 | 1817 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 93 | success |
| cut-on | 5 | PASS | ok | — | 0.1906 | 1530 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "exit=$LASTEXITC` | — | 83 | success |
| cut-on | 6 | PASS | ok | — | 0.2062 | 1685 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 89 | success |
| pin-on | 1 | PASS | ok | — | 0.3302 | 2099 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 129 | success |
| pin-on | 2 | PASS | ok | — | 0.3195 | 1814 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 125 | success |
| pin-on | 3 | PASS | ok | — | 0.3251 | 2317 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 144 | success |
| pin-on | 4 | PASS | ok | — | 0.2054 | 1617 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 104 | success |
| pin-on | 5 | PASS | ok | — | 0.2127 | 1832 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 95 | success |
| pin-on | 6 | PASS | ok | — | 0.1999 | 1767 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 106 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
