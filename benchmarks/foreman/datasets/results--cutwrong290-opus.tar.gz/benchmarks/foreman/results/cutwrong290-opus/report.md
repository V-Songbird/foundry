# foreman handoff benchmark — run `cutwrong290-opus`

12 runs · model `opus` · generated from `results/cutwrong290-opus/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **cut-wrong** | 6 | 17% | 100% | 0.2186 | 2141 | 113943 | 8 | 5.5 | 2 (2–2) | 7 (6–7) | 100% | 2.5 | 33 |
| **unpin-wrong** | 6 | 100% | 100% | 0.2288 | 2567 | 107494 | 8 | 5.2 | 3 (3–4) | 7 (7–8) | 100% | 0.0 | 33 |

## unpinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-wrong | 6 | 17% | 100% | 0.2186 | 2141 | 113943 | 8 | 5.5 | 2 (2–2) | 7 (6–7) | 100% | 2.5 | 33 |
| unpin-wrong | 6 | 100% | 100% | 0.2288 | 2567 | 107494 | 8 | 5.2 | 3 (3–4) | 7 (7–8) | 100% | 0.0 | 33 |

### Per-rep rows — unpinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cut-wrong | 1 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.2122 | 1842 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 93 | success |
| cut-wrong | 2 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.2407 | 2671 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 60` | — | 153 | success |
| cut-wrong | 3 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.2022 | 1867 | 10 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 65 | success |
| cut-wrong | 4 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.2089 | 1747 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 86 | success |
| cut-wrong | 5 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.2210 | 2110 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 121 | success |
| cut-wrong | 6 | PASS | ok | — | 0.2266 | 2611 | 6 | 2 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 121 | success |
| unpin-wrong | 1 | PASS | ok | — | 0.2427 | 3045 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 140 | success |
| unpin-wrong | 2 | PASS | ok | — | 0.2253 | 2568 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 30; "EXIT=$LASTEXITC` | — | 141 | success |
| unpin-wrong | 3 | PASS | ok | — | 0.2238 | 2527 | 6 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 131 | success |
| unpin-wrong | 4 | PASS | ok | — | 0.2405 | 2607 | 10 | 4 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 136 | success |
| unpin-wrong | 5 | PASS | ok | — | 0.2274 | 2570 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 142 | success |
| unpin-wrong | 6 | PASS | ok | — | 0.2131 | 2085 | 10 | 3 | `node --test 2>&1 \| Select-Object -Last 40; "EXIT=$LASTEXITC` | — | 140 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
