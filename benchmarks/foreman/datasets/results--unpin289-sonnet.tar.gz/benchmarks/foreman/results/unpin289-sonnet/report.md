# foreman handoff benchmark — run `unpin289-sonnet`

12 runs · model `sonnet` · generated from `results/unpin289-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **unpin-off** | 6 | 100% | 100% | 0.0894 | 1436 | 115381 | 6 | 4.3 | 2 (2–2) | 5 (5–6) | 100% | 0.0 | 19 |
| **unpin-wrong** | 6 | 17% | 100% | 0.0966 | 1879 | 117094 | 11 | 4.3 | 2 (2–3) | 6 (5–7) | 100% | 2.5 | 28 |

## unpinned-dup

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-off | 6 | 100% | 100% | 0.0894 | 1436 | 115381 | 6 | 4.3 | 2 (2–2) | 5 (5–6) | 100% | 0.0 | 19 |
| unpin-wrong | 6 | 17% | 100% | 0.0966 | 1879 | 117094 | 11 | 4.3 | 2 (2–3) | 6 (5–7) | 100% | 2.5 | 28 |

### Per-rep rows — unpinned-dup

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| unpin-off | 1 | PASS | ok | — | 0.0973 | 1468 | 15 | 2 | `node --test 2>&1` | — | 49 | success |
| unpin-off | 2 | PASS | ok | — | 0.0854 | 1431 | 0 | 2 | `node --test` | — | 47 | success |
| unpin-off | 3 | PASS | ok | — | 0.0849 | 1397 | 0 | 2 | `node --test` | — | 54 | success |
| unpin-off | 4 | PASS | ok | — | 0.0973 | 1453 | 19 | 2 | `node --test 2>&1` | — | 35 | success |
| unpin-off | 5 | PASS | ok | — | 0.0847 | 1361 | 0 | 2 | `node --test` | — | 39 | success |
| unpin-off | 6 | PASS | ok | — | 0.0867 | 1508 | 0 | 2 | `node --test` | — | 37 | success |
| unpin-wrong | 1 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.1052 | 2764 | 0 | 2 | `node --test` | — | 95 | success |
| unpin-wrong | 2 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0808 | 1040 | 0 | 2 | `node --test` | — | 67 | success |
| unpin-wrong | 3 | PASS | ok | — | 0.1207 | 3051 | 0 | 3 | `node --test` | — | 112 | success |
| unpin-wrong | 4 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0944 | 1177 | 26 | 2 | `node --test 2>&1` | — | 67 | success |
| unpin-wrong | 5 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0862 | 1415 | 37 | 2 | `node --test` | — | 67 | success |
| unpin-wrong | 6 | FAIL | ok | sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove; sentinel: src/stats.js still contains a line the task was sent to remove | 0.0921 | 1827 | 0 | 2 | `node --test` | — | 71 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
