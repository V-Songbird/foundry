# foreman handoff benchmark — run `ex4a-sonnet`

12 runs · model `sonnet` · generated from `results/ex4a-sonnet/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **extras-off** | 6 | 100% | 100% | 0.0917 | 452 | 97238 | 19 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |
| **extras-on** | 6 | 100% | 100% | 0.0639 | 451 | 97880 | 18 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |

## quiet-extras

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 6 | 100% | 100% | 0.0917 | 452 | 97238 | 19 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |
| extras-on | 6 | 100% | 100% | 0.0639 | 451 | 97880 | 18 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 11 |

### Per-rep rows — quiet-extras

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| extras-off | 1 | PASS | ok | — | 0.1203 | 454 | 18 | 1 | `node --test` | — | 23 | success |
| extras-off | 2 | PASS | ok | — | 0.1201 | 440 | 19 | 1 | `node --test` | — | 18 | success |
| extras-off | 3 | PASS | ok | — | 0.1202 | 447 | 14 | 1 | `node --test` | — | 27 | success |
| extras-off | 4 | PASS | ok | — | 0.0631 | 457 | 22 | 1 | `node --test` | — | 22 | success |
| extras-off | 5 | PASS | ok | — | 0.0633 | 470 | 21 | 1 | `node --test` | — | 19 | success |
| extras-off | 6 | PASS | ok | — | 0.0630 | 442 | 19 | 1 | `node --test` | — | 18 | success |
| extras-on | 1 | PASS | ok | — | 0.0639 | 455 | 19 | 1 | `node --test` | — | 24 | success |
| extras-on | 2 | PASS | ok | — | 0.0638 | 441 | 19 | 1 | `node --test` | — | 18 | success |
| extras-on | 3 | PASS | ok | — | 0.0640 | 463 | 18 | 1 | `node --test` | — | 25 | success |
| extras-on | 4 | PASS | ok | — | 0.0639 | 449 | 17 | 1 | `node --test` | — | 22 | success |
| extras-on | 5 | PASS | ok | — | 0.0638 | 440 | 18 | 1 | `node --test` | — | 18 | success |
| extras-on | 6 | PASS | ok | — | 0.0639 | 455 | 19 | 1 | `node --test` | — | 25 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
