# foreman handoff benchmark — run `proof-sn`

48 runs · model `sonnet` · generated from `results/proof-sn/runs/`

Arms differ by prompt file only; every arm except `vibe` carries the same brief facts. Judge on per-rep spread, not the mean alone.

## Overall (mean per run, all tasks pooled)

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **vibe** | 12 | 92% | 100% | 0.1058 | 1224 | 153870 | 38 | 6.3 | 4 (3–7) | 7 (6–10) | 100% | 0.2 | 19 |
| **freeform** | 12 | 100% | 100% | 0.0759 | 883 | 125091 | 26 | 5.1 | 4 (1–7) | 7 (4–10) | 100% | 0.0 | 15 |
| **webtemplate** | 12 | 100% | 100% | 0.0774 | 977 | 129133 | 18 | 5.3 | 3 (1–6) | 6 (4–9) | 100% | 0.0 | 16 |
| **shape-off** | 12 | 100% | 100% | 0.0853 | 1093 | 153617 | 32 | 6.2 | 4 (1–7) | 7 (4–10) | 100% | 0.0 | 18 |

## adjacent-mess

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| vibe | 4 | 100% | 100% | 0.0765 | 811 | 128894 | 33 | 5.3 | 3 (3–3) | 6 (6–6) | 100% | 0.0 | 14 |
| freeform | 4 | 100% | 100% | 0.0645 | 517 | 97415 | 17 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 12 |
| webtemplate | 4 | 100% | 100% | 0.0654 | 579 | 97643 | 0 | 4.0 | 1 (1–1) | 4 (4–4) | 100% | 0.0 | 12 |
| shape-off | 4 | 100% | 100% | 0.0792 | 956 | 131167 | 52 | 5.3 | 3 (1–5) | 6 (4–8) | 100% | 0.0 | 15 |

### Per-rep rows — adjacent-mess

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| vibe | 1 | PASS | ok | — | 0.0745 | 753 | 35 | 3 | `node --test tests/stats.test.js` | — | 31 | success |
| vibe | 2 | PASS | ok | — | 0.0750 | 794 | 18 | 3 | `node --test tests/stats.test.js` | — | 36 | success |
| vibe | 3 | PASS | ok | — | 0.0811 | 891 | 45 | 3 | `node --test tests/stats.test.js` | — | 40 | success |
| vibe | 4 | PASS | ok | — | 0.0752 | 805 | 35 | 3 | `node --test tests/stats.test.js` | — | 23 | success |
| freeform | 1 | PASS | ok | — | 0.0645 | 518 | 15 | 1 | `node --test` | — | 25 | success |
| freeform | 2 | PASS | ok | — | 0.0648 | 540 | 27 | 1 | `node --test` | — | 24 | success |
| freeform | 3 | PASS | ok | — | 0.0642 | 497 | 9 | 1 | `node --test` | — | 26 | success |
| freeform | 4 | PASS | ok | — | 0.0644 | 511 | 17 | 1 | `node --test` | — | 24 | success |
| webtemplate | 1 | PASS | ok | — | 0.0653 | 575 | 0 | 1 | `node --test 2>&1` | — | 57 | success |
| webtemplate | 2 | PASS | ok | — | 0.0654 | 588 | 0 | 1 | `node --test` | — | 67 | success |
| webtemplate | 3 | PASS | ok | — | 0.0653 | 572 | 0 | 1 | `node --test 2>&1` | — | 52 | success |
| webtemplate | 4 | PASS | ok | — | 0.0654 | 581 | 0 | 1 | `node --test 2>&1` | — | 56 | success |
| shape-off | 1 | PASS | ok | — | 0.0865 | 1213 | 50 | 4 | `node --test` | — | 22 | success |
| shape-off | 2 | PASS | ok | — | 0.0951 | 1301 | 58 | 5 | `node --test` | — | 43 | success |
| shape-off | 3 | PASS | ok | — | 0.0673 | 629 | 48 | 1 | `node --test` | — | 24 | success |
| shape-off | 4 | PASS | ok | — | 0.0681 | 682 | 53 | 1 | `node --test` | — | 24 | success |

## api-constraint

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| vibe | 4 | 75% | 100% | 0.1496 | 1220 | 178997 | 53 | 7.3 | 4 (4–5) | 7 (7–8) | 100% | 0.5 | 21 |
| freeform | 4 | 100% | 100% | 0.0757 | 822 | 123996 | 29 | 5.0 | 4 (2–4) | 7 (5–7) | 100% | 0.0 | 16 |
| webtemplate | 4 | 100% | 100% | 0.0763 | 876 | 129420 | 30 | 5.3 | 3 (2–4) | 6 (5–7) | 100% | 0.0 | 17 |
| shape-off | 4 | 100% | 100% | 0.0796 | 891 | 137215 | 37 | 5.5 | 3 (2–3) | 6 (5–6) | 100% | 0.0 | 15 |

### Per-rep rows — api-constraint

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| vibe | 1 | FAIL | ok | unchanged: index.js was modified (must stay byte-identical); mustChange: src/limiter.js is byte-identical to pristine (no fix landed there) | 0.1476 | 1173 | 58 | 4 | `node --test tests/limiter.test.js` | — | 50 | success |
| vibe | 2 | PASS | ok | — | 0.1481 | 1198 | 48 | 4 | `node --test tests/limiter.test.js` | — | 44 | success |
| vibe | 3 | PASS | ok | — | 0.1544 | 1274 | 44 | 5 | `node --test tests/limiter.test.js` | — | 42 | success |
| vibe | 4 | PASS | ok | — | 0.1485 | 1236 | 63 | 4 | `node --test tests/limiter.test.js` | — | 59 | success |
| freeform | 1 | PASS | ok | — | 0.0778 | 899 | 29 | 4 | `node --test` | — | 42 | success |
| freeform | 2 | PASS | ok | — | 0.0775 | 878 | 28 | 4 | `node --test` | — | 42 | success |
| freeform | 3 | PASS | ok | — | 0.0765 | 808 | 28 | 4 | `node --test` | — | 37 | success |
| freeform | 4 | PASS | ok | — | 0.0711 | 703 | 31 | 2 | `node --test` | — | 35 | success |
| webtemplate | 1 | PASS | ok | — | 0.0786 | 931 | 23 | 4 | `node --test 2>&1` | — | 62 | success |
| webtemplate | 2 | PASS | ok | — | 0.0728 | 794 | 32 | 2 | `node --test 2>&1` | — | 56 | success |
| webtemplate | 3 | PASS | ok | — | 0.0814 | 1006 | 38 | 2 | `node --test 2>&1` | — | 58 | success |
| webtemplate | 4 | PASS | ok | — | 0.0725 | 772 | 27 | 2 | `node --test 2>&1` | — | 57 | success |
| shape-off | 1 | PASS | ok | — | 0.0753 | 800 | 36 | 2 | `node --test` | — | 35 | success |
| shape-off | 2 | PASS | ok | — | 0.0830 | 902 | 30 | 3 | `node --test` | — | 34 | success |
| shape-off | 3 | PASS | ok | — | 0.0750 | 811 | 27 | 2 | `node --test` | — | 38 | success |
| shape-off | 4 | PASS | ok | — | 0.0852 | 1051 | 55 | 3 | `node --test` | — | 35 | success |

## moved-file

| Arm | n | Correct (all checks) | Tests pass | Cost USD | Output tok | Traffic tok | Narration w | API calls | Reads before 1st edit (min–max) | Turns (min–max) | Verification ran | Violations/run | Wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| vibe | 4 | 100% | 100% | 0.0912 | 1642 | 153718 | 27 | 6.3 | 6 (5–7) | 9 (8–10) | 100% | 0.0 | 22 |
| freeform | 4 | 100% | 100% | 0.0875 | 1310 | 153864 | 32 | 6.3 | 6 (6–7) | 9 (9–10) | 100% | 0.0 | 18 |
| webtemplate | 4 | 100% | 100% | 0.0904 | 1475 | 160338 | 23 | 6.5 | 6 (5–6) | 9 (8–9) | 100% | 0.0 | 20 |
| shape-off | 4 | 100% | 100% | 0.0969 | 1430 | 192469 | 8 | 7.8 | 6 (4–7) | 9 (7–10) | 100% | 0.0 | 24 |

### Per-rep rows — moved-file

| Arm | Rep | Pass | Tests | Violations | Cost USD | Output tok | Narration w | Reads | Verify command | Mismatch named | Final words | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| vibe | 1 | PASS | ok | — | 0.0950 | 1609 | 50 | 7 | `node --test tests/tokenizer.test.js` | yes | 44 | success |
| vibe | 2 | PASS | ok | — | 0.0939 | 1971 | 0 | 5 | `node --test tests/tokenizer.test.js` | yes | 76 | success |
| vibe | 3 | PASS | ok | — | 0.0845 | 1250 | 42 | 6 | `node --test tests/tokenizer.test.js` | yes | 38 | success |
| vibe | 4 | PASS | ok | — | 0.0913 | 1737 | 15 | 6 | `node --test tests/tokenizer.test.js` | yes | 47 | success |
| freeform | 1 | PASS | ok | — | 0.0831 | 1104 | 31 | 6 | `node --test` | yes | 43 | success |
| freeform | 2 | PASS | ok | — | 0.0917 | 1312 | 35 | 7 | `node --test` | yes | 21 | success |
| freeform | 3 | PASS | ok | — | 0.0899 | 1587 | 27 | 6 | `node --test` | yes | 51 | success |
| freeform | 4 | PASS | ok | — | 0.0854 | 1238 | 36 | 6 | `node --test` | no | 4 | success |
| webtemplate | 1 | PASS | ok | — | 0.0946 | 1592 | 36 | 6 | `node --test 2>&1` | yes | 72 | success |
| webtemplate | 2 | PASS | ok | — | 0.0889 | 1534 | 0 | 6 | `node --test 2>&1` | yes | 79 | success |
| webtemplate | 3 | PASS | ok | — | 0.0904 | 1311 | 23 | 5 | `node --test` | yes | 97 | success |
| webtemplate | 4 | PASS | ok | — | 0.0877 | 1462 | 32 | 5 | `node --test` | yes | 78 | success |
| shape-off | 1 | PASS | ok | — | 0.0936 | 1119 | 13 | 6 | `node --test` | no | 62 | success |
| shape-off | 2 | PASS | ok | — | 0.0941 | 1186 | 19 | 5 | `node --test` | no | 67 | success |
| shape-off | 3 | PASS | ok | — | 0.0945 | 1558 | 0 | 4 | `node --test` | no | 52 | success |
| shape-off | 4 | PASS | ok | — | 0.1054 | 1858 | 0 | 7 | `node --test 2>&1` | no | 76 | success |

---

Honesty checklist before quoting any number: same-batch arms only; check each rep's `finalText` for truncation-fabricated runs (`resultSubtype` != `success` is a red flag); n>=4 per cell before claiming anything.
